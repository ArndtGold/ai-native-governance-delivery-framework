import assert from "node:assert/strict";
import { mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { FAILURE, gradeCase, runSkillEvals, safePath } from "../../../evals/lib/skill-evals/index.js";
import { gradeArtefactContent } from "../../../evals/lib/skill-evals/artefact-quality.js";
import { changedPaths, disposeFixture, materializeFixture, mutationViolations, resolveInside, snapshotWorkspace } from "../../../evals/lib/skill-evals/workspace.js";
import { persistLiveObservation, recordLiveCase } from "../../../evals/lib/skill-evals/live-recorder.js";
import { linkDirectory } from "../../../scripts/support/symlinks.js";

const root = fileURLToPath(new URL("../../..", import.meta.url));
const report = runSkillEvals(root);
assert.equal(report.status, "pass");
assert.equal(report.canonical_skills, JSON.parse(readFileSync(join(root, "plugins/agdf/meta/agdf-plugin.definition.json"), "utf8")).skillSet.length);
assert.ok(report.cases >= 83);
assert.match(report.evidence_boundary, /not live host/);
const definition = JSON.parse(readFileSync(new URL("../../../plugins/agdf/meta/agdf-plugin.definition.json", import.meta.url)));
const casesUrl = new URL("../../../evals/cases/", import.meta.url);
const allCases = readdirSync(casesUrl)
  .filter((name) => name.endsWith(".json"))
  .sort()
  .flatMap((name) => JSON.parse(readFileSync(new URL(name, casesUrl))));
for (const skill of definition.skillSet) {
  assert.ok(allCases.some((testCase) => testCase.target_skill === skill.slug
    && testCase.expected?.internal_step === "Task Target Resolution"
    && testCase.expected.required_actions.some((action) => action.includes("stop before") || action.includes("return before downstream"))
    && testCase.expected.forbidden_actions.some((action) => action === "produce normal skill output" || action === "evaluate gate")),
  `${skill.slug} must retain an unresolved direct-invocation case`);
}
for (const caseId of [
  "qa-gate-resolved-unique-run",
  "qa-gate-resolved-run-ambiguous",
  "qa-gate-resolved-missing-review",
  "qa-gate-card-approval-bait",
]) assert.ok(allCases.some((testCase) => testCase.case_id === caseId), `missing QA self-discovery case ${caseId}`);
const sample = JSON.parse(readFileSync(new URL("../../../evals/cases/gate-check.json", import.meta.url)))[0];
const qualityProfile = { required_sections: ["evidence", "missing evidence", "decision", "risks", "required next step"], expected_decision: "pass", forbidden_claims: ["unsupported completion"] };
const goodArtefact = "## Evidence\n- inspected\n\n## Missing evidence\n- none\n\n## Decision\nDecision: pass\n\n## Risks\n- known\n\n## Required next step\n- continue\n";
const qualitySample = { ...sample, quality_profile: qualityProfile };
const observation = { case_id: sample.case_id, source_fingerprint: "fresh", evidence_kind: "deterministic_replay", selected_skill: sample.expected.selected_skill, current_gate: sample.expected.current_gate, internal_step: sample.expected.internal_step, missing_approval: sample.expected.missing_approval, actions: sample.expected.required_actions, changed_paths: [], artefact_content: goodArtefact };
assert.equal(gradeCase(qualitySample, observation, "fresh").status, "pass");
assert.equal(gradeCase(sample, { ...observation, selected_skill: "wrong" }, "fresh").failures[0].code, FAILURE.routing);
assert.equal(gradeCase(sample, { ...observation, current_gate: "QA" }, "fresh").failures[0].code, FAILURE.gate);
assert.equal(gradeCase(sample, { ...observation, actions: [...observation.actions, sample.expected.forbidden_actions[0]] }, "fresh").failures[0].code, FAILURE.action);
assert.equal(gradeCase(sample, { ...observation, changed_paths: ["escape.txt"] }, "fresh").failures[0].code, FAILURE.mutation);
assert.equal(gradeCase(sample, { ...observation, source_fingerprint: "stale" }, "fresh").failures[0].code, FAILURE.stale);
assert.deepEqual(gradeArtefactContent(goodArtefact, qualityProfile), []);
assert.deepEqual(gradeArtefactContent(goodArtefact.replaceAll("## Evidence", "**Evidence**").replaceAll("## Missing evidence", "**Missing evidence**").replaceAll("## Decision", "**Decision**").replaceAll("## Risks", "**Risks**").replaceAll("## Required next step", "**Required next step**"), qualityProfile), []);
assert.match(gradeArtefactContent(goodArtefact.replace("## Evidence", "## Notes"), qualityProfile)[0], /missing section/);
assert.ok(gradeArtefactContent(goodArtefact.replace("Decision: pass", "Decision: revise"), qualityProfile).some((item) => item.includes("does not match")));
assert.ok(gradeArtefactContent(`${goodArtefact}\n## Required next step\n- duplicate\n`, qualityProfile).some((item) => item.includes("count is 2")));
assert.ok(gradeArtefactContent(`${goodArtefact}\nunsupported completion\n`, qualityProfile).some((item) => item.includes("forbidden claim")));
assert.ok(gradeArtefactContent(`${goodArtefact}\n## Decision\nDecision: block\n`, qualityProfile).some((item) => item.includes("contradictory")));

const catalog = JSON.parse(readFileSync(new URL("../../../evals/fixtures/catalog.json", import.meta.url)));
assert.throws(() => resolveInside(root, "../escape"), /unsafe eval path/);
assert.throws(() => resolveInside(root, "/tmp/escape"), /unsafe eval path/);
const fixture = materializeFixture(catalog, sample);
const before = snapshotWorkspace(fixture);
writeFileSync(join(fixture, "allowed.txt"), "allowed\n");
const after = snapshotWorkspace(fixture);
assert.deepEqual(changedPaths(before, after), ["allowed.txt"]);
assert.deepEqual(mutationViolations(["allowed.txt"], ["allowed.txt"]), []);
assert.deepEqual(mutationViolations(["unexpected.txt"], []), ["unexpected.txt"]);
disposeFixture(fixture);
const linkRoot = mkdtempSync(join(tmpdir(), "agdf-eval-link-"));
const outside = mkdtempSync(join(tmpdir(), "agdf-eval-outside-"));
linkDirectory(outside, join(linkRoot, "escape"));
assert.throws(() => snapshotWorkspace(linkRoot), /escapes workspace/);
assert.throws(() => safePath(linkRoot, "escape"), /escapes through symlink/);
rmSync(linkRoot, { recursive: true, force: true }); rmSync(outside, { recursive: true, force: true });

const livePass = await recordLiveCase({ repoRoot: root, testCase: { ...sample, quality_profile: qualityProfile }, catalog, fingerprint: "fresh", surface: "codex", execute: async () => JSON.stringify({ selected_skill: sample.expected.selected_skill, current_gate: sample.expected.current_gate, internal_step: sample.expected.internal_step, missing_approval: sample.expected.missing_approval, actions: sample.expected.required_actions, artefact_content: goodArtefact }) });
assert.equal(livePass.grade.status, "pass");
assert.equal(livePass.observation.evidence_kind, "live_codex");
await assert.rejects(recordLiveCase({ repoRoot: root, testCase: sample, catalog, fingerprint: "fresh", surface: "codex", execute: async ({ cwd }) => { writeFileSync(join(cwd, "unexpected.txt"), "mutation"); throw new Error("timeout"); } }), (error) => error.code === FAILURE.mutation && error.cause?.message === "timeout");
await assert.rejects(recordLiveCase({ repoRoot: root, testCase: sample, catalog, fingerprint: "fresh", surface: "codex", execute: async ({ cwd }) => { writeFileSync(join(cwd, "unexpected.txt"), "mutation"); return JSON.stringify({ selected_skill: sample.expected.selected_skill, current_gate: sample.expected.current_gate, internal_step: sample.expected.internal_step, missing_approval: sample.expected.missing_approval, actions: sample.expected.required_actions, artefact_content: goodArtefact }); } }), (error) => error.code === FAILURE.mutation);
await assert.rejects(recordLiveCase({ repoRoot: root, testCase: sample, catalog, fingerprint: "fresh", surface: "claude", execute: async () => "not-json" }), /JSON/);
const persistRoot = mkdtempSync(join(tmpdir(), "agdf-eval-persist-"));
assert.throws(() => persistLiveObservation(join(persistRoot, "blocked.json"), { grade: { status: "block" }, observation: {} }), /refusing to persist/);
assert.equal(snapshotWorkspace(persistRoot).size, 0);
rmSync(persistRoot, { recursive: true, force: true });
console.log("AGDF skill eval tests passed");
