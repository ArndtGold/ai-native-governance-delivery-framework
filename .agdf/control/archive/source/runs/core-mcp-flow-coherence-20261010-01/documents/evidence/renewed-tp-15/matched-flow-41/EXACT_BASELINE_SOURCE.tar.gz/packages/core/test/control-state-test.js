import { prepareRunPresentation } from "../lib/control-state/run-presentation.js";
import "./artefact-recording-test.js";
import assert from "node:assert/strict";
import {
  existsSync,
  cpSync,
  mkdtempSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  symlinkSync,
  writeFileSync,
} from "node:fs";
import { execFileSync, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { tmpdir } from "node:os";
import { join } from "node:path";
import {
  aggregate,
  approveRunGate,
  createRun,
  discoverRuns,
  migrateLegacy,
  parseRunState,
  recordRunRevision,
  renderLegacyProjection,
  resolveRuns,
  runSealState,
  verifyLegacyProjection,
  writeRun,
  validateGateApprovalResponse,
} from "../lib/control-state/index.js";
import { parseControlState, RUN_ID_PATTERN } from "../lib/control-state/run-state-parser.js";
import { sealRunState } from "../lib/control-state/run-seal.js";
import { validateRunIdentity, RUN_ID_PATTERN as identityRunIdPattern } from "../lib/control-state/run-identity.js";
import { evaluateGateCheck, postApprovalTransition, printApprovalEnvelope, printGateCheckReport } from "../lib/control-evaluation/gate-check.js";
import { evaluateDoctor } from "../lib/control-evaluation/doctor.js";
import { policyForRunContent } from "../lib/control-evaluation/run-step-policy.js";
import { recordRunStep } from "../lib/control-state/run-steps.js";
import { initializeCanonicalControl } from "../../cli/lib/scaffold/canonical-init.js";
import { generatedFilesForTarget } from "../../cli/lib/scaffold/plan.js";
import { transitionDecisionForRunState } from "../lib/control-evaluation/gate-policy.js";
import { normalizeBacklogStatus } from "../lib/control-evaluation/shared.js";
import { buildBreadcrumb, buildTransitionNarration, collapseInternalState } from "../lib/interaction-presentation.js";

const pluginRoot = join(import.meta.dirname, "..", "..", "..", "plugins", "agdf");
const localeRegistry = JSON.parse(readFileSync(join(pluginRoot, "meta", "agdf-interaction-locales.json"), "utf8"));

// The fixtures are English control repositories. `init` otherwise adopts the host locale, and a
// non-English chat language legitimately changes presentation, e.g. untranslated next steps
// then require user action. Pin the locale for the spawned CLI and in-process readers.
process.env.LC_ALL = "en_US.UTF-8";

const root = mkdtempSync(join(tmpdir(), "agdf-control-state-"));
const cli = join(import.meta.dirname, "..", "..", "cli", "bin", "create-agdf.js");
try {
  const approvalCandidate = Object.freeze({
    response: "Approval: TP",
    responseOrigin: "deliberate_user_input",
    expectedApproval: "Approval: TP",
    expectedRunId: "run-a",
    currentRunId: "run-a",
    expectedGate: "TP",
    currentGate: "TP",
    expectedRevisionId: "revision-a",
    currentRevisionId: "revision-a",
    durableArtefactReady: true,
  });
  assert.deepEqual(validateGateApprovalResponse(approvalCandidate), { accepted: true, reason: "accepted" });
  assert.deepEqual(validateGateApprovalResponse({ ...approvalCandidate, responseOutcome: "approve" }), { accepted: true, reason: "accepted" });
  assert.deepEqual(validateGateApprovalResponse({ ...approvalCandidate, response: "Approve", responseOutcome: "approve" }), { accepted: false, reason: "wrong_or_non_approval_response" });
  for (const [name, override, reason] of [
    ["unavailable adapter result", { response: undefined, noResponse: true }, "no_response"],
    ["non-deliberate response", { responseOrigin: "hook" }, "non_deliberate_response"],
    ["empty response", { response: "" }, "empty_response"],
    ["revise", { responseOutcome: "revise" }, "revision_requested"],
    ["decline", { responseOutcome: "decline" }, "declined"],
    ["cancel", { responseOutcome: "cancel" }, "cancelled"],
    ["timeout", { timedOut: true }, "timed_out"],
    ["invalid", { response: "Approve" }, "wrong_or_non_approval_response"],
    ["stale outcome", { responseOutcome: "stale" }, "stale_response"],
    ["formula mismatch", { expectedApproval: "Approval: QA" }, "approval_formula_mismatch"],
    ["stale gate", { currentGate: "QA" }, "changed_or_wrong_gate"],
    ["changed run", { currentRunId: "run-b" }, "changed_or_wrong_run"],
    ["stale revision", { currentRevisionId: "revision-b" }, "stale_revision"],
    ["missing artefact", { durableArtefactReady: false }, "durable_artefact_not_ready"],
  ]) {
    const before = JSON.stringify(approvalCandidate);
    assert.deepEqual(
      validateGateApprovalResponse({ ...approvalCandidate, ...override }),
      { accepted: false, reason },
      name,
    );
    assert.equal(JSON.stringify(approvalCandidate), before, `${name} must not mutate control input`);
  }

  execFileSync(process.execPath, [cli, "init", "--dir", root]);
  const a = createRun(root, "run-a", "## Objective\n\nA\n");
  assert.equal(discoverRuns(root).length, 1);
  assert.equal(resolveRuns(root, {}).run.run_id, "run-a");
  createRun(root, "run-b", "## Objective\n\nB\n");
  assert.deepEqual(discoverRuns(root).map((run) => run.run_id), ["run-a", "run-b"]);
  assert.throws(() => resolveRuns(root, {}), /AGDF_ACTIVE_RUN_AMBIGUOUS/);
  assert.equal(resolveRuns(root, { runIdArg: "run-b" }).run.run_id, "run-b");
  assert.equal(resolveRuns(root, { runIdEnv: "run-a" }).selection_source, "environment");
  assert.equal(resolveRuns(root, { runIdArg: "run-a", runIdEnv: "run-a" }).run.run_id, "run-a");
  assert.throws(() => resolveRuns(root, { runIdArg: "unknown" }), /AGDF_RUN_NOT_SELECTABLE/);
  assert.throws(() => resolveRuns(root, { runIdArg: "run-a", allActive: true }), /AGDF_SELECTOR_CONFLICT/);
  assert.throws(
    () => resolveRuns(root, { runIdArg: "run-a", runIdEnv: "run-b" }),
    /AGDF_SELECTOR_CONFLICT/,
  );
  const parsed = parseRunState(readFileSync(a, "utf8"), "run-a");
  assert.equal(parsed.valid, true);
  const controlStateFixture = `# AGDF Run State

## Approvals

| Gate | Status | Evidence |
|---|---|---|
| UR | approved | Approval: UR |
| QA | pass | QA report |

## Artefacts

| Type | Path | Status | Notes |
|---|---|---|---|
| Brownfield Review | BROWNFIELD_REVIEW.md | done | reviewed |
| Brownfield Analysis | BROWNFIELD_ANALYSIS.md | done | analysed |
| CD+Tests | CD_TESTS.md | done | tested |
| CR | CODE_REVIEW.md | done | reviewed |
| QA | QA_REPORT.md | passed | report status remains passed |
| OR | \`OR.md\` | done | closed |

## Mode/Slice Decision

- decision: structured_slice
- required_next_gate: PRD
- scope_reason: Canonical heading evidence.
- evidence: BROWNFIELD_REVIEW.md
`;
  const parsedControlState = parseControlState(controlStateFixture, {
    userGates: ["UR", "PRD", "SD", "TP", "QA", "UAT"],
    internalSteps: ["Brownfield Review", "Brownfield Analysis", "CD+Tests", "CR"],
    closeoutArtefacts: ["OR"],
  });
  assert.equal(parsedControlState.approvals.get("QA")?.status, "approved");
  assert.equal(parsedControlState.artefacts.get("QA")?.status, "passed");
  assert.deepEqual(
    [...parsedControlState.artefacts.keys()],
    ["Brownfield Review", "Brownfield Analysis", "CD+Tests", "CR", "QA", "OR"],
  );
  assert.deepEqual(parsedControlState.artefact_row_duplicates, []);
  assert.equal(parsedControlState.artefacts.get("OR")?.path, "OR.md");
  assert.equal(parsedControlState.artefacts.get("OR")?.path_format, "code_span");
  const invalidPathState = parseControlState(controlStateFixture.replace("`OR.md`", "`OR.md"), { closeoutArtefacts: ["OR"] });
  assert.equal(invalidPathState.artefacts.get("OR")?.path_format, "invalid");
  assert.equal(invalidPathState.artefacts.get("OR")?.path_reason, "unmatched_delimiter");
  for (const malformed of ["OR.md`", "``OR.md``", "`OR`-copy.md"]) {
    const malformedState = parseControlState(controlStateFixture.replace("`OR.md`", malformed), { closeoutArtefacts: ["OR"] });
    assert.equal(malformedState.artefacts.get("OR")?.path_format, "invalid", `${malformed} must remain invalid`);
  }
  assert.equal(parsedControlState.mode_slice_decision.decision, "structured_slice");
  const atomicBrownfieldFixture = controlStateFixture.replace(
    "| Brownfield Review | BROWNFIELD_REVIEW.md | done | reviewed |",
    "| UR | UR.md | approved | durable |\n| Brownfield Review | BROWNFIELD_REVIEW.md | done | reviewed |",
  );
  const atomicBrownfield = parseControlState(atomicBrownfieldFixture, { userGates: ["UR", "PRD"], internalSteps: ["Brownfield Review"] });
  assert.equal(transitionDecisionForRunState(atomicBrownfield).current_gate, "PRD", "completed Brownfield Review and mode selection route atomically");
  const interruptedBrownfield = parseControlState(atomicBrownfieldFixture.replace(/## Mode\/Slice Decision[\s\S]*$/, ""), {
    userGates: ["UR", "PRD"], internalSteps: ["Brownfield Review"],
  });
  assert.equal(transitionDecisionForRunState(interruptedBrownfield).current_gate, "Mode/Slice Decision", "interrupted atomic routing fails closed to recovery");
  const invalidBrownfieldEvidence = parseControlState(atomicBrownfieldFixture.replace("- evidence: BROWNFIELD_REVIEW.md", "- evidence:"), {
    userGates: ["UR", "PRD"], internalSteps: ["Brownfield Review"],
  });
  assert.equal(transitionDecisionForRunState(invalidBrownfieldEvidence).current_gate, "Mode/Slice Decision", "unevidenced routing fails closed to recovery");
  const activeQuickTask = {
    ...atomicBrownfield,
    content: "- lifecycle: active",
    current_gate: "Quick Task Execution",
    mode_slice_decision: { ...atomicBrownfield.mode_slice_decision, decision: "quick_task", required_next_gate: "none" },
  };
  assert.deepEqual(
    { status: transitionDecisionForRunState(activeQuickTask).status, current_gate: transitionDecisionForRunState(activeQuickTask).current_gate },
    { status: "open", current_gate: "Quick Task Execution" },
    "active Quick Task remains open",
  );
  const completedQuickTask = {
    ...activeQuickTask,
    content: "- lifecycle: completed",
    current_gate: "OR",
    artefacts: new Map([...activeQuickTask.artefacts, ["OR", { path: "OR.md", status: "done" }]]),
  };
  assert.deepEqual(
    { status: transitionDecisionForRunState(completedQuickTask).status, current_gate: transitionDecisionForRunState(completedQuickTask).current_gate },
    { status: "pass", current_gate: "OR" },
    "completed Quick Task with OR projects pass instead of reopening execution",
  );
  assert.deepEqual(
    {
      status: transitionDecisionForRunState({ ...completedQuickTask, content: "- lifecycle: active" }).status,
      current_gate: transitionDecisionForRunState({ ...completedQuickTask, content: "- lifecycle: active" }).current_gate,
    },
    { status: "open", current_gate: "Quick Task Execution" },
    "Quick Task with OR does not project pass while lifecycle remains active",
  );
  const qaReviseRoot = mkdtempSync(join(tmpdir(), "agdf-qa-revise-"));
  execFileSync(process.execPath, [cli, "init", "--dir", qaReviseRoot]);
  rmSync(join(qaReviseRoot, ".agdf", "control", "AGDF_RUN.md"), { force: true });
  execFileSync(process.execPath, [cli, "run-create", "--dir", qaReviseRoot, "--run", "qa-revise"]);
  const qaArtefactDir = join(qaReviseRoot, ".agdf", "control", "artefacts", "qa-revise");
  mkdirSync(qaArtefactDir, { recursive: true });
  for (const name of ["UR.md", "PRD.md", "SD.md", "TP.md", "QA_REPORT.md"]) writeFileSync(join(qaArtefactDir, name), `# ${name}\n`);
  writeFileSync(join(qaReviseRoot, ".agdf", "control", "runs", "qa-revise", "RUN_STATE.md"), `# AGDF Run State

## Run Meta

- control_state_version: 2
- run_id: qa-revise
- lifecycle: active
- revision: 1
- revision_id: 11111111-1111-4111-8111-111111111111
- mode: structured_delivery
- current_gate: QA
- decision: revise
- owner: test

## Approvals

| Gate | Status | Evidence |
|---|---|---|
| UR | approved | Approval: UR |
| PRD | approved | Approval: PRD |
| SD | approved | Approval: SD |
| TP | approved | Approval: TP |
| QA | missing |  |
| UAT | missing |  |

## Artefacts

| Type | Path | Status | Notes |
|---|---|---|---|
| UR | .agdf/control/artefacts/qa-revise/UR.md | approved | ready |
| PRD | .agdf/control/artefacts/qa-revise/PRD.md | approved | ready |
| SD | .agdf/control/artefacts/qa-revise/SD.md | approved | ready |
| TP | .agdf/control/artefacts/qa-revise/TP.md | approved | ready |
| Brownfield Review | BROWNFIELD_REVIEW.md | done | ready |
| Brownfield Analysis | BROWNFIELD_ANALYSIS.md | done | ready |
| CD+Tests | CD_TESTS.md | done | ready |
| CR | CODE_REVIEW.md | done | ready |
| QA | .agdf/control/artefacts/qa-revise/QA_REPORT.md | revise | QA revision required |

## Mode/Slice Decision

- decision: structured_delivery
- required_next_gate: PRD
- scope_reason: Test QA revise projection.
- evidence: fixture

## Artefact Chain

| From | Relationship | To | Status | Evidence |
|---|---|---|---|---|
| UR | approved_by | Approval: UR | approved | fixture |
| PRD | derived_from | UR | approved | fixture |
| SD | derived_from | PRD | approved | fixture |
| TP | derived_from | SD | approved | fixture |
| QA_REPORT | tests | TP | pass | fixture |

## Closeout

- next_allowed_action: Resolve QA findings.
- quality_outlook: QA revise.
`);
  const qaRunPath = join(qaReviseRoot, ".agdf", "control", "runs", "qa-revise", "RUN_STATE.md");
  writeFileSync(qaRunPath, sealRunState(qaReviseRoot, readFileSync(qaRunPath, "utf8")));
  const qaReviseGateCheck = spawnSync(process.execPath, [cli, "gate-check", "--dir", qaReviseRoot, "--run", "qa-revise", "--json"], { encoding: "utf8" });
  assert.equal(qaReviseGateCheck.status, 0, qaReviseGateCheck.stderr);
  const qaReviseReport = JSON.parse(qaReviseGateCheck.stdout);
  assert.equal(qaReviseReport.current_gate, "QA");
  assert.equal(qaReviseReport.blocking_reason, "qa_revise_required");
  assert.equal(qaReviseReport.missing_approval, "none");
  assert.ok(qaReviseReport.allowed.every((action) => !action.includes("approval")));
  assert.ok(qaReviseReport.forbidden.includes("request QA approval"));
  // Unclassified QA revise stays non-approvable and cannot grant blanket implementation.
  assert.equal(qaReviseReport.status_card.user_action_required, "no");
  assert.match(qaReviseReport.status_card.internal_next_step, /through their authoritative owner before dependent work/);
  assert.ok(qaReviseReport.forbidden.includes("implement code"));
  assert.ok(!qaReviseReport.allowed.includes("revise the implementation against the QA findings"));
  assert.equal(qaReviseReport.status_card.next_gate_after_approval, "none");
  assert.equal(Object.hasOwn(qaReviseReport.status_card, "approvalOrientation"), false, "approval orientation must not change public JSON keys");

  const qaBlockRunPath = join(qaReviseRoot, ".agdf", "control", "runs", "qa-revise", "RUN_STATE.md");
  writeFileSync(
    qaBlockRunPath,
    sealRunState(qaReviseRoot, readFileSync(qaBlockRunPath, "utf8")
      .replace("| QA | .agdf/control/artefacts/qa-revise/QA_REPORT.md | revise | QA revision required |", "| QA | .agdf/control/artefacts/qa-revise/QA_REPORT.md | block | QA blocked |")
      .replace("- next_allowed_action: Resolve QA findings.", "- next_allowed_action: Route blocking QA findings.")),
  );
  const qaBlockGateCheck = spawnSync(process.execPath, [cli, "gate-check", "--dir", qaReviseRoot, "--run", "qa-revise", "--json"], { encoding: "utf8" });
  assert.equal(qaBlockGateCheck.status, 2, qaBlockGateCheck.stderr);
  const qaBlockReport = JSON.parse(qaBlockGateCheck.stdout);
  assert.equal(qaBlockReport.status, "blocked");
  assert.equal(qaBlockReport.current_gate, "QA");
  assert.equal(qaBlockReport.blocking_reason, "qa_blocked");
  assert.equal(qaBlockReport.missing_approval, "none");
  assert.ok(qaBlockReport.allowed.every((action) => !action.includes("approval")));
  assert.ok(qaBlockReport.allowed.includes("route the blocking QA findings to their authoritative owner"));
  assert.ok(qaBlockReport.forbidden.includes("request QA approval"));
  assert.ok(qaBlockReport.forbidden.includes("request UAT approval"));
  assert.equal(qaBlockReport.interaction_kind, "blocked");
  assert.equal(qaBlockReport.approval_presentation, null);
  // QA block routes the finding to its owner without creating a new user gate approval.
  assert.equal(qaBlockReport.status_card.user_action_required, "no");
  assert.equal(qaBlockReport.status_card.internal_next_step, "Route blocking QA findings.");
  assert.equal(qaBlockReport.status_card.next_gate_after_approval, "none");

  writeFileSync(
    qaBlockRunPath,
    sealRunState(qaReviseRoot, readFileSync(qaBlockRunPath, "utf8").replace("| QA | missing |  |", "| QA | approved | Approval: QA |")),
  );
  const approvedQaBlockGateCheck = spawnSync(process.execPath, [cli, "gate-check", "--dir", qaReviseRoot, "--run", "qa-revise", "--json"], { encoding: "utf8" });
  assert.equal(approvedQaBlockGateCheck.status, 2, approvedQaBlockGateCheck.stderr);
  const approvedQaBlockReport = JSON.parse(approvedQaBlockGateCheck.stdout);
  assert.equal(approvedQaBlockReport.status, "blocked");
  assert.equal(approvedQaBlockReport.current_gate, "QA");
  assert.equal(approvedQaBlockReport.blocking_reason, "AGDF_GATE_ARTEFACT_STATUS_INCONSISTENT");
  assert.equal(approvedQaBlockReport.missing_approval, "none");
  assert.ok(approvedQaBlockReport.allowed.every((action) => !action.includes("UAT")));
  assert.ok(approvedQaBlockReport.forbidden.includes("create later-gate artefacts beyond the current allowed gate"));
  rmSync(qaReviseRoot, { recursive: true, force: true });

  for (const gate of ["UR", "PRD", "SD", "TP", "QA", "UAT"]) {
    const readyRoot = mkdtempSync(join(tmpdir(), `agdf-ready-${gate.toLowerCase()}-`));
    execFileSync(process.execPath, [cli, "init", "--dir", readyRoot]);
    rmSync(join(readyRoot, ".agdf", "control", "AGDF_RUN.md"), { force: true });
    const runId = `ready-${gate.toLowerCase()}`;
    execFileSync(process.execPath, [cli, "run-create", "--dir", readyRoot, "--run", runId]);
    const artefactDir = join(readyRoot, ".agdf", "control", "artefacts", runId);
    mkdirSync(artefactDir, { recursive: true });
    const approvalDocs = {
      "UR.md": "# UR\n\n## 1. Problem\nUsers need a clear gate summary.\n\n## 2. Goal\nReview the exact linked document.\n\n## 3. Scope\nAdd a concise summary before approval.\n\n## 5. Acceptance Signals\n| ID | Result |\n|---|---|\n| UR-01 | Summary matches this revision. |\n\n## 7. Risks And Unknowns\nWhether the link opens in each host.\n## AGDF Approval Summary (de; source=en)\n- Problem: Nutzer brauchen eine klare Gate-Zusammenfassung.\n- Ziel: Das exakt verlinkte Dokument prüfen.\n- Umfang: Eine knappe Zusammenfassung vor der Freigabe ergänzen.\n",
      "PRD.md": "# PRD\n\nOwner: Product Owner\n\n## 1. Product Scope\nAfter an approved UR and a completed Brownfield Review that selects structured_delivery or structured_slice, prepare and persist a reviewable PRD before presenting the next user decision card. The PRD card must link the exact draft and summarize its intent.\n\n## 2. UX Intent And Success\n- primary_user_intent: inspect the product requirements before deciding whether to approve them\n- success_signal: the next PRD card links a durable draft and includes a concise relevant summary\n- primary_decision_or_action: approve, request revision, or decline the PRD\n\n## 5. Acceptance Criteria\n- criterion_id: PRD-CARD-001; working_mode: structured_delivery; source_state: UR approved, Brownfield Review done, PRD absent; trigger/action: continue the same run; expected effective state: a PRD draft is persisted before the next user card; visible feedback: no PRD approval card is shown while the draft is absent; observable success: the PRD artefact exists and is recorded in the run.\n- criterion_id: PRD-CARD-002; working_mode: structured_delivery; source_state: PRD draft persisted; trigger/action: prepare the PRD decision card; expected effective state: the card is bound to the exact PRD and revision; visible feedback: a concise summary and clickable PRD link appear before the approval choice; observable success: the card and linked artefact identify the same run and revision.\n\n## 6. Non-Goals\nDo not replace the source document.\n\n## 10. Risks And Open Questions\nConfirm host links.\n\n## Approval Decisions\n\n| Decision | Timing | Status | Resolution | Owner |\n|---|---|---|---|---|\n| Card link target | before_prd | resolved | Link the exact PRD revision. | Product Owner |\n\n## AGDF Approval Summary (de; source=en)\n- Nutzerziel: Die Produktanforderungen vor der Entscheidung über ihre Freigabe prüfen.\n- Umfang: Ein dauerhaftes PRD mit klarer Absicht und passendem Entscheidungslink vorlegen.\n- Entscheidungen:\n  - Card link target (geklärt): Die exakt geprüfte PRD-Revision verlinken.\n- Abnahmekriterien:\n  - PRD-CARD-001: Das PRD wird gespeichert und im Run erfasst, bevor eine Freigabekarte erscheint.\n  - PRD-CARD-002: Karte und Link verweisen auf denselben Run und dieselbe Revision.\n",
      "SD.md": "# SD\n\n## 1. Solution Overview\nRender deterministic summaries from the source artefact.\n\n## 2. Ownership And Source Of Truth\nThe artefact remains authoritative.\n\n## 3. Architecture Decisions\nBind summary and link to the revision digest.\n\n## 4. Integration Points\nrun-present produces the review text.\n\n## 7. Risks And Open Questions\nHost path support.\n## AGDF Approval Summary (de; source=en)\n- Lösung: Deterministische Zusammenfassungen aus dem Quellartefakt rendern.\n- Verantwortung: Das Artefakt bleibt maßgeblich.\n- Entscheidungen: Zusammenfassung und Link an den Revisions-Digest binden.\n",
      "TP.md": "# TP\n\n## 1. Task List\n| task_id | Task | Acceptance mapping | Evidence required |\n|---|---|---|---|\n| T1 | Render summary | PRD-01 | Unit test |\n\n## 2. Test Plan\nRun source and packaged runtime tests.\n\n## 4. Out Of Scope\nChange approval authority.\n\n## 5. Risks And Blockers\nHost-specific path rendering.\n## AGDF Approval Summary (de; source=en)\n- Aufgaben: T1 Zusammenfassung rendern (PRD-01, Unit-Test).\n- Risiken: Host-spezifische Pfaddarstellung.\n",
      "QA_REPORT.md": "# QA Report\n\n## 1. QA Decision\nDecision: revise until live-tested.\n\n## 2. TP Coverage\nSummary and digest are tested.\n\n## 3. Evidence\nSource and packaged runtime tests passed.\n\n## 4. Missing Evidence\nFresh host interaction.\n\n## 5. Risks\nPaths vary by host.\n\n## 6. Required Next Step\nRun the live host test.\n## AGDF Approval Summary (de; source=en)\n- Entscheidung: Überarbeiten bis zum Live-Test.\n- Nachweise: Quell- und Paket-Runtime-Tests bestanden.\n- Lücken: Frische Host-Interaktion fehlt.\n",
    };
    for (const name of ["UR.md", "PRD.md", "SD.md", "TP.md", "QA_REPORT.md", "BROWNFIELD_REVIEW.md", "BROWNFIELD_ANALYSIS.md", "CD_TESTS.md", "CODE_REVIEW.md"]) {
      writeFileSync(join(artefactDir, name), approvalDocs[name] ?? `# ${name}\n`);
    }
    const gateIndex = ["UR", "PRD", "SD", "TP", "QA", "UAT"].indexOf(gate);
    const approvals = ["UR", "PRD", "SD", "TP", "QA", "UAT"].map((candidate, index) =>
      `| ${candidate} | ${index < gateIndex ? "approved" : "missing"} | ${index < gateIndex ? `Approval: ${candidate}` : ""} |`,
    ).join("\n");
    writeFileSync(join(readyRoot, ".agdf", "control", "runs", runId, "RUN_STATE.md"), `# AGDF Run State

## Run Meta

- control_state_version: 2
- run_id: ${runId}
- lifecycle: active
- revision: 1
- revision_id: 22222222-2222-4222-8222-${String(gateIndex + 1).padStart(12, "0")}
- mode: structured_delivery
- current_gate: ${gate}
- decision: in_progress
- owner: test

## Objective

Ready ${gate} approval fixture.

## Approvals

| Gate | Status | Evidence |
|---|---|---|
${approvals}

## Artefacts

| Type | Path | Status | Notes |
|---|---|---|---|
| UR | .agdf/control/artefacts/${runId}/UR.md | approved | ready |
| Brownfield Review | .agdf/control/artefacts/${runId}/BROWNFIELD_REVIEW.md | done | ready |
| PRD | .agdf/control/artefacts/${runId}/PRD.md | approved | ready |
| SD | .agdf/control/artefacts/${runId}/SD.md | approved | ready |
| TP | .agdf/control/artefacts/${runId}/TP.md | approved | ready |
| Brownfield Analysis | .agdf/control/artefacts/${runId}/BROWNFIELD_ANALYSIS.md | done | ready |
| CD+Tests | .agdf/control/artefacts/${runId}/CD_TESTS.md | done | ready |
| CR | .agdf/control/artefacts/${runId}/CODE_REVIEW.md | done | ready |
| QA | .agdf/control/artefacts/${runId}/QA_REPORT.md | pass | ready |

## Mode / Slice Decision

- decision: structured_delivery
- required_next_gate: PRD
- scope_reason: Gate-readiness matrix fixture.
- evidence: fixture

## Artefact Chain

| From | Relationship | To | Status | Evidence |
|---|---|---|---|---|
| UR | approved_by | Approval: UR | approved | fixture |
| PRD | derived_from | UR | approved | fixture |
| SD | derived_from | PRD | approved | fixture |
| TP | derived_from | SD | approved | fixture |
| QA_REPORT | tests | TP | pass | fixture |

## Evidence

| Evidence | Source | Covers | Strength |
|---|---|---|---|
| Ready fixture | test | ${gate} | direct |

## Next Allowed Action

- next_allowed_action: Request exact Approval: ${gate}.
`);
    const readyRunPath = join(readyRoot, ".agdf", "control", "runs", runId, "RUN_STATE.md");
    writeFileSync(readyRunPath, sealRunState(readyRoot, readFileSync(readyRunPath, "utf8")));
    const ready = spawnSync(process.execPath, [cli, "gate-check", "--dir", readyRoot, "--run", runId, "--json"], { encoding: "utf8" });
    assert.equal(ready.status, 0, `${gate}: ${ready.stderr}${ready.stdout.slice(0, 1500)}`);
    const report = JSON.parse(ready.stdout);
    assert.equal(report.status, "open", `${gate} ready gate must remain open independently of native capability`);
    assert.equal(report.current_gate, gate);
    assert.equal(report.missing_approval, `Approval: ${gate}`);
    assert.equal(report.interaction_kind, "gate_approval");
    assert.ok(report.approval_presentation, `${gate}: ${JSON.stringify(report.presentation_diagnostics)}`);
    assert.equal(report.native_attempt_required, false, "report-only evaluation has no verified host adapter capability");
    const sealed = recordRunRevision(readyRoot, { runId, revisionId: report.approval_presentation.revision_id });
    assert.equal(sealed.outcome, "unchanged");
    // The wording below is English; pin it so the check does not follow the machine locale.
    const prepared = prepareRunPresentation(readyRoot, { runId, gate, revisionId: sealed.revision_id, language: "en" }, { evaluateGateCheck });
    assert.equal(prepared.outcome, "prepared", `${gate} must prepare: ${JSON.stringify(prepared)}`);
    const reviewable = evaluateGateCheck(readyRoot, { runId, presentationLanguage: "en" });
    assert.equal(reviewable.approval_presentation?.markdown, prepared.text,
      `${gate} gate-check and run-present must show the same artefact-bound review text`);
    const statusLines = [];
    assert.equal(printGateCheckReport(reviewable, false, true, { log: (line) => statusLines.push(line) }), true);
    assert.equal(statusLines.join("\n"), reviewable.approval_presentation.preview_markdown,
      `${gate} status-card output is a read-only artefact preview without an approval choice`);
    assert.doesNotMatch(statusLines.join("\n"), /Approval: (?:UR|PRD|SD|TP|QA|UAT)/u);
    assert.ok(prepared.text.includes("Next step: Review the linked artefact; choose an option below."),
      `${gate} summary or options are clearly identified as the next user action`);
    assert.match(prepared.artefact_digest, /^sha256:[0-9a-f]{64}$/u, `${gate} presentation binds the actual artefact body`);
    assert.match(prepared.summary_digest, /^sha256:[0-9a-f]{64}$/u, `${gate} presentation binds its summary`);
    const visibleGateContent = gate === "UAT" ? /## (?:Vorliegende UAT-Evidenz|Available UAT evidence)/u : new RegExp(`(?:Artefakt|Artefact): \\[${gate === "QA" ? "QA_REPORT.md" : `${gate}.md`}\\]`);
    assert.ok(typeof visibleGateContent === "string" ? prepared.text.includes(visibleGateContent) : visibleGateContent.test(prepared.text), `${gate} approval links the exact artefact or presents existing UAT evidence`);
    assert.ok(prepared.text.includes(`Revision: \`${sealed.revision_id}\``), `${gate} approval identifies the revision under review`);
    assert.ok(prepared.text.includes(`| Your decision | Approval: ${gate} · Revise · Decline |`),
      `${gate} card separates the user's decision from agent work`);
    assert.match(prepared.text, /\| Agent may work on now \|/u, `${gate} card labels allowed work as agent work`);
    if (gate === "PRD") {
      assert.match(prepared.text, /\| Your decision \|/u);
      assert.doesNotMatch(prepared.text, /\| Allowed now \|/u);
      assert.doesNotMatch(prepared.text, /\| Next step \| Review the linked artefact/u,
        "the detailed card avoids repeating the top-level user action");
      assert.match(prepared.text, /- User intent: Inspect the product requirements before deciding whether to approve them/u,
        "PRD summary uses the user's intent rather than a long process scope");
      assert.match(prepared.text, /- Success: The next PRD card links a durable draft and includes a concise relevant summary/u,
        "PRD summary surfaces the success signal");
      assert.doesNotMatch(prepared.text, /\| (?:Next step|Next gate after approval|Allowed after approval|Quality outlook) \|/u,
        "the approval-ready detail card omits repeated transition and no-op quality rows");
      const germanPrepared = prepareRunPresentation(readyRoot, { runId, gate, revisionId: sealed.revision_id, language: "de" }, { evaluateGateCheck });
      assert.equal(germanPrepared.outcome, "prepared", `German PRD summary must prepare: ${JSON.stringify(germanPrepared)}`);
      assert.match(germanPrepared.text, /Nächster Schritt: Prüfe das verlinkte Artefakt und wähle unten eine Option\./u,
        "German card directs the reviewer to the linked artefact and available choices");
      assert.ok(germanPrepared.text.includes("| Deine Entscheidung | Approval: PRD · Überarbeiten · Ablehnen |"),
        "German card localizes the decision options while preserving the exact approval token");
      assert.match(germanPrepared.text, /Quellsprache: Englisch · Zusammenfassung in gewählter Sprache/u,
        "German card identifies the source language while keeping the summary localized");
      assert.match(germanPrepared.text, /PRD-CARD-001: Das PRD wird gespeichert und im Run erfasst/u,
        "German approval summary includes the first criterion in German");
      assert.match(germanPrepared.text, /PRD-CARD-002: Karte und Link verweisen auf denselben Run/u,
        "German approval summary includes every criterion in German");
      assert.doesNotMatch(germanPrepared.text, /No PRD approval card is shown|A concise summary and clickable PRD link/u,
        "German approval summary does not expose unmarked English source text");
      const criterionSummaryVariants = [
        ["approval_summary_locale_missing", (text) => text.replace(/\n## AGDF Approval Summary \(de; source=en\)[\s\S]*$/u, "")],
        ["approval_summary_criteria_duplicate", (text) => text.replace("PRD-CARD-002: Karte und Link verweisen", "PRD-CARD-001: Karte und Link verweisen")],
        ["approval_summary_criteria_unknown", (text) => text.replace("PRD-CARD-002: Karte und Link verweisen", "PRD-CARD-999: Karte und Link verweisen")],
        ["approval_summary_criteria_incomplete", (text) => text.replace("  - PRD-CARD-002: Karte und Link verweisen auf denselben Run und dieselbe Revision.\n", "")],
        ["approval_summary_truncated_or_overlong", (text) => text.replace("Die Produktanforderungen vor der Entscheidung", "Die Produktanforderungen… vor der Entscheidung")],
      ];
      const readyPrdPath = join(readyRoot, ".agdf", "control", "artefacts", runId, "PRD.md");
      const readyPrd = readFileSync(readyPrdPath, "utf8");
      for (const [expectedCode, mutate] of criterionSummaryVariants) {
        const invalidRoot = mkdtempSync(join(tmpdir(), `agdf-summary-${expectedCode}-`));
        try {
          cpSync(readyRoot, invalidRoot, { recursive: true });
          const invalidPrdPath = join(invalidRoot, ".agdf", "control", "artefacts", runId, "PRD.md");
          writeFileSync(invalidPrdPath, mutate(readyPrd));
          const invalidStatePath = join(invalidRoot, ".agdf", "control", "runs", runId, "RUN_STATE.md");
          const invalidRevision = readFileSync(invalidStatePath, "utf8").match(/^- revision_id: (.+)$/mu)?.[1];
          assert.ok(invalidRevision, `${expectedCode}: copied run has a revision`);
          assert.equal(recordRunRevision(invalidRoot, { runId, revisionId: invalidRevision }).outcome, "updated");
          const invalidReport = evaluateGateCheck(invalidRoot, { runId, presentationLanguage: "de" });
          assert.ok(invalidReport.prd_readiness?.open_decisions?.some(item => item.includes(expectedCode)),
            `${expectedCode}: ${JSON.stringify(invalidReport.presentation_diagnostics)}`);
          assert.equal(invalidReport.approval_presentation, null, `${expectedCode} never prepares a partial approval`);
          const recoveryLines = [];
          printGateCheckReport(invalidReport, false, true, { log: (line) => recoveryLines.push(line) });
          assert.ok(recoveryLines.join("\n").includes("AGDF Approval Summary (de; source=en)"), `${expectedCode} shows exact summary recovery`);
          assert.ok(recoveryLines.join("\n").includes(invalidPrdPath), `${expectedCode} links the exact artefact`);
          assert.doesNotMatch(recoveryLines.join("\n"), /Approval: PRD · Überarbeiten · Ablehnen/u,
            `${expectedCode} does not ask for a decision on an incomplete summary`);
          const rejectedPresentation = prepareRunPresentation(invalidRoot, {
            runId, gate, revisionId: invalidReport.status_presentation.revision_id, language: "de",
          }, { evaluateGateCheck });
          assert.equal(rejectedPresentation.outcome, "rejected");
          assert.equal(rejectedPresentation.reason, "AGDF_PRD_DECISIONS_OPEN");
          assert.ok(rejectedPresentation.recovery.includes(expectedCode), "the early refusal preserves its exact validator reason");
          assert.ok(rejectedPresentation.recovery.includes(invalidPrdPath));
        } finally {
          rmSync(invalidRoot, { recursive: true, force: true });
        }
      }
      assert.doesNotMatch(germanPrepared.text, /criterion_id|working_mode: structured_delivery|source_state:/u,
        "internal criterion metadata is not exposed as the acceptance summary");
      assert.match(prepared.text, /After your PRD approval, the agent drafts the Solution Design\. Once the draft is ready, you will review and decide on the Solution Design\./u,
        "the post-approval sequence separates agent drafting from the user's next decision");
    }
    const summaryPosition = prepared.text.search(new RegExp(`## (?:Kurzfassung|Review summary) · ${gate}`));
    const actionPosition = Math.min(...[prepared.text.indexOf("Jetzt freigeben"), prepared.text.indexOf("Approve now")].filter((position) => position >= 0));
    assert.ok(summaryPosition >= 0 && actionPosition > summaryPosition, `${gate} summary appears before the approval action`);
    const approved = approveRunGate(readyRoot, { runId, gate, revisionId: sealed.revision_id,
      response: `Approval: ${gate}`, presentationId: prepared.presentation_id }, { evaluateGateCheck });
    assert.equal(approved.outcome, "approved", `${gate} bound response must persist: ${JSON.stringify(approved)}`);
    const afterApproval = parseRunState(readFileSync(join(readyRoot, ".agdf", "control", "runs", runId, "RUN_STATE.md"), "utf8"));
    const nextGate = { UR: "PRD", PRD: "SD", SD: "TP", TP: "QA", QA: "UAT", UAT: "OR" }[gate];
    assert.equal(afterApproval.meta.current_gate, nextGate, `${gate} approval advances persisted current_gate`);
    assert.match(afterApproval.content, new RegExp(`^- next_allowed_action: .*(?:${nextGate}|${gate === "TP" ? "implementation" : "close"}).*$`, "m"), `${gate} approval refreshes the persisted next action`);
    assert.doesNotMatch(afterApproval.content, new RegExp(`\\| What is missing\\? \\| Exact Approval: ${gate}\\. \\|`), `${gate} is no longer reported as missing`);
    rmSync(readyRoot, { recursive: true, force: true });
  }
  // Writers reject duplicate artefact rows, and older sealed duplicates still block presentation.
  {
    const duplicateRoot = mkdtempSync(join(tmpdir(), "agdf-duplicate-artefact-"));
    try {
      initializeCanonicalControl(duplicateRoot, generatedFilesForTarget("init", duplicateRoot, false, "de"));
      const statePath = createRun(duplicateRoot, "duplicate-prd");
      const original = readFileSync(statePath, "utf8");
      const relativePrd = ".agdf/control/artefacts/duplicate-prd/PRD.md";
      const absolutePrd = join(duplicateRoot, relativePrd);
      mkdirSync(join(duplicateRoot, ".agdf", "control", "artefacts", "duplicate-prd"), { recursive: true });
      writeFileSync(absolutePrd, "# PRD: Duplicate row\n\n## Product Scope\nReviewable content.\n");
      const duplicate = original.replace("| PRD |  | missing |  |",
        `| PRD | \`${relativePrd}\` | draft |  |\n| PRD |  | missing |  |`);
      writeFileSync(statePath, duplicate);
      const revisionId = parseRunState(original).meta.revision_id;
      const rejectedDuplicate = recordRunRevision(duplicateRoot, { runId: "duplicate-prd", revisionId });
      assert.equal(rejectedDuplicate.reason, "artefact_row_duplicate");
      assert.deepEqual(rejectedDuplicate.artefact_types, ["PRD"]);
      assert.match(rejectedDuplicate.recovery, /Keep one Artefacts row per type/u);
      assert.throws(() => writeRun(statePath, duplicate, revisionId), /AGDF_RUN_SEAL_INVALID/u);
      assert.equal(readFileSync(statePath, "utf8"), duplicate, "rejected writes must preserve the run");
      writeFileSync(statePath, sealRunState(duplicateRoot, duplicate), "utf8");
      assert.equal(runSealState(duplicateRoot, readFileSync(statePath, "utf8")).status, "valid");
      assert.throws(() => writeRun(statePath, duplicate, revisionId), /AGDF_ARTEFACT_ROW_DUPLICATE/u);
      assert.equal(recordRunRevision(duplicateRoot, { runId: "duplicate-prd", revisionId }).reason,
        "artefact_row_duplicate", "a legacy sealed duplicate is not an unchanged success");
      const doctor = evaluateDoctor(duplicateRoot, { runId: "duplicate-prd" });
      assert.equal(doctor.status, "block");
      assert.ok(doctor.findings.some((finding) => finding.code === "AGDF_ARTEFACT_ROW_DUPLICATE"));
      const report = evaluateGateCheck(duplicateRoot, { runId: "duplicate-prd", presentationLanguage: "de" });
      assert.equal(report.blocking_reason, "AGDF_ARTEFACT_ROW_DUPLICATE");
      assert.equal(report.approval_presentation, null);
      assert.equal(report.status_card.missing_approval, "none", "a blocked card must not display an approval token");
      assert.equal(report.status_card.next_gate_after_approval, "none", "a blocked card must not suggest a transition");
      const statusLines = [];
      assert.equal(printGateCheckReport(report, false, true, { log: (line) => statusLines.push(line) }), true);
      assert.doesNotMatch(statusLines.join("\n"), /Approval: PRD|Nach Freigabe erlaubt|Nächstes Gate nach Freigabe/u);
      assert.equal(report.allowed.some((item) => item.includes("approval")), false);
      const lines = [];
      const envelope = printApprovalEnvelope(report, { io: { log: (line) => lines.push(line) } });
      assert.equal(envelope.requested_decision, false);
      assert.doesNotMatch(lines.join("\n"), /Approval: PRD/u);
      assert.equal(prepareRunPresentation(duplicateRoot, { runId: "duplicate-prd", gate: "UR", revisionId }, { evaluateGateCheck }).reason,
        "AGDF_ARTEFACT_ROW_DUPLICATE");
      writeFileSync(statePath, readFileSync(statePath, "utf8").replace("\n| PRD |  | missing |  |", ""));
      const repaired = recordRunRevision(duplicateRoot, { runId: "duplicate-prd", revisionId });
      assert.equal(repaired.outcome, "updated", "removing the extra row remains repairable");
      assert.equal(runSealState(duplicateRoot, readFileSync(statePath, "utf8")).status, "valid");
      assert.equal(evaluateDoctor(duplicateRoot, { runId: "duplicate-prd" }).findings.some((finding) =>
        finding.code === "AGDF_ARTEFACT_ROW_DUPLICATE"), false);
    } finally {
      rmSync(duplicateRoot, { recursive: true, force: true });
    }
  }
  const legacyMode = parseControlState(
    controlStateFixture.replace("## Mode/Slice Decision", "## Mode / Slice Decision"),
    { userGates: ["QA"], internalSteps: [] },
  );
  assert.equal(legacyMode.mode_slice_decision.decision, "structured_slice");
  const canonicalPrecedence = parseControlState(`${controlStateFixture}
## Mode / Slice Decision

- decision: block
- required_next_gate: none
- scope_reason: Legacy duplicate.
- evidence: legacy
`, { userGates: ["QA"], internalSteps: [] });
  assert.equal(canonicalPrecedence.mode_slice_decision.decision, "structured_slice");
  for (const status of ["pass", "passed", "approved"]) {
    const qaState = parseControlState(controlStateFixture.replace("| QA | pass | QA report |", `| QA | ${status} | QA report |`), {
      userGates: ["QA"],
      internalSteps: [],
    });
    assert.equal(qaState.approvals.get("QA")?.status, "approved");
  }
  for (const [replacement, code] of [
    ["- lifecycle: broken", "AGDF_RUN_LIFECYCLE_INVALID"],
    ["- revision: 0", "AGDF_RUN_REVISION_INVALID"],
    ["- control_state_version: 9", "AGDF_RUN_VERSION_UNSUPPORTED"],
  ]) {
    const bad = parsed.content.replace(
      /^- (lifecycle|revision|control_state_version):.*$/m,
      replacement,
    );
    assert.ok(
      parseRunState(bad, "run-a").findings.some((f) => f.code === code),
    );
  }
  assert.ok(
    parseRunState(
      parsed.content.replace("- run_id: run-a", "- run_id: run-a\n- run_id: run-a"),
      "run-a",
    ).findings.some((f) => f.code === "AGDF_RUN_FIELD_DUPLICATE"),
  );
  assert.ok(
    parseRunState(parsed.content, "different-run").findings.some(
      (finding) => finding.code === "AGDF_RUN_PATH_MISMATCH",
    ),
  );
  assert.ok(
    parseRunState(parsed.content.replace("- run_id: run-a", "- run_id: ../escape"), "run-a").findings.some(
      (finding) => finding.code === "AGDF_RUN_ID_INVALID",
    ),
  );
  assert.ok(
    parseRunState(parsed.content.replace(/^- revision_id:.*$/m, "- revision_id: invalid"), "run-a").findings.some(
      (finding) => finding.code === "AGDF_RUN_REVISION_ID_INVALID",
    ),
  );
  assert.ok(
    parseRunState(`${parsed.content}\n| malformed table row`, "run-a").findings.some(
      (finding) => finding.code === "AGDF_RUN_TABLE_INVALID",
    ),
  );
  assert.throws(
    () => writeRun(a, parsed.content, "stale"),
    /AGDF_STALE_RUN_REVISION/,
  );
  assert.equal(
    writeRun(a, parsed.content, parsed.meta.revision_id).meta.revision,
    "2",
  );
  assert.equal(readdirSync(join(root, ".agdf", "control", "runs", "run-a")).some((entry) => entry.includes(".tmp-")), false);
  assert.equal(readdirSync(join(root, ".agdf", "control", "runs", "run-a")).some((entry) => entry.endsWith(".lock")), false);
  const lockedState = parseRunState(readFileSync(a, "utf8"), "run-a");
  writeFileSync(`${a}.lock`, "held");
  assert.throws(() => writeRun(a, lockedState.content, lockedState.meta.revision_id), /AGDF_RUN_WRITE_LOCKED/);
  rmSync(`${a}.lock`);

  const emptyRoot = mkdtempSync(join(tmpdir(), "agdf-control-empty-"));
  assert.throws(() => resolveRuns(emptyRoot), /AGDF_ACTIVE_RUN_MISSING/);
  rmSync(emptyRoot, { recursive: true, force: true });
  assert.equal(
    aggregate([
      { run_id: "b", status: "warn" },
      { run_id: "a", status: "block" },
    ]).status,
    "block",
  );
  assert.equal(aggregate([]).status, "revise");
  assert.equal(aggregate([], { allowNoActiveRuns: true }).status, "pass");

  const cliRoot = mkdtempSync(join(tmpdir(), "agdf-control-cli-"));
  const help = execFileSync(process.execPath, [cli, "--help"], { encoding: "utf8" });
  for (const expected of ["--run <run_id>", "--all-active", "run-create", "run-migrate", "run-render-legacy"]) {
    assert.match(help, new RegExp(expected.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
  }
  const missingScaffoldRun = spawnSync(process.execPath, [cli, "run-create", "--dir", cliRoot, "--run", "cli-run"], { encoding: "utf8" });
  assert.notEqual(missingScaffoldRun.status, 0);
  assert.match(missingScaffoldRun.stderr, /AGDF_CANONICAL_SCAFFOLD_REQUIRED/);
  assert.equal(existsSync(join(cliRoot, ".agdf")), false, "run-create must not create a dead-end control tree before init");
  execFileSync(process.execPath, [cli, "init", "--dir", cliRoot]);
  execFileSync(process.execPath, [cli, "run-create", "--dir", cliRoot, "--run", "cli-run"]);
  assert.ok(readFileSync(join(cliRoot, ".agdf", "control", "runs", "cli-run", "RUN_STATE.md"), "utf8").includes("- run_id: cli-run"));
  const cliLegacyPath = join(cliRoot, ".agdf", "control", "AGDF_RUN.md");
  writeFileSync(cliLegacyPath, "# AGDF Run State\n\nunmarked legacy\n");
  const mixedAuthority = spawnSync(process.execPath, [cli, "doctor", "--dir", cliRoot, "--all-active", "--json"], { encoding: "utf8" });
  assert.notEqual(mixedAuthority.status, 0);
  assert.ok(JSON.parse(mixedAuthority.stdout).findings.some((finding) => finding.code === "AGDF_LEGACY_PROJECTION_DRIFT"));
  rmSync(cliLegacyPath);
  const illegalAllActive = spawnSync(process.execPath, [cli, "gate-check", "--dir", cliRoot, "--all-active"], { encoding: "utf8" });
  assert.notEqual(illegalAllActive.status, 0);
  assert.match(illegalAllActive.stderr, /--all-active is supported only/);
  assert.doesNotMatch(illegalAllActive.stderr, /\n\s+at\s|node:internal|file:\/\//, "expected option errors must not expose a Node stack trace");
  const missingRenderSelector = spawnSync(process.execPath, [cli, "run-render-legacy", "--dir", cliRoot], { encoding: "utf8" });
  assert.notEqual(missingRenderSelector.status, 0);
  assert.match(missingRenderSelector.stderr, /requires --run/);
  rmSync(cliRoot, { recursive: true, force: true });

  const ambiguousRoot = mkdtempSync(join(tmpdir(), "agdf-control-ambiguous-"));
  execFileSync(process.execPath, [cli, "init", "--dir", ambiguousRoot]);
  rmSync(join(ambiguousRoot, ".agdf", "control", "AGDF_RUN.md"), { force: true });
  execFileSync(process.execPath, [cli, "run-create", "--dir", ambiguousRoot, "--run", "ambiguous-run-a"]);
  execFileSync(process.execPath, [cli, "run-create", "--dir", ambiguousRoot, "--run", "ambiguous-run-b"]);
  for (const target of ["doctor", "gate-check", "delivery-map"]) {
    const ambiguous = spawnSync(process.execPath, [cli, target, "--dir", ambiguousRoot, "--json"], { encoding: "utf8" });
    assert.notEqual(ambiguous.status, 0);
    assert.equal(ambiguous.stderr, "", `${target} must not crash with a raw stack trace on an ambiguous multi-run selection`);
    const report = JSON.parse(ambiguous.stdout);
    const findings = report.doctor_report?.findings ?? report.findings ?? [];
    assert.ok(
      findings.some((finding) => finding.code === "AGDF_ACTIVE_RUN_AMBIGUOUS"),
      `${target} must report AGDF_ACTIVE_RUN_AMBIGUOUS as a structured finding instead of throwing`,
    );
    if (target === "gate-check") {
      assert.deepEqual(report.candidate_runs.map((candidate) => candidate.run_id), ["ambiguous-run-a", "ambiguous-run-b"]);
      assert.ok(report.candidate_runs.every((candidate) => candidate.display_title && candidate.current_gate));
      assert.equal(report.native_attempt_required, false, "ambiguous runs must never require a native approval attempt");
      assert.notEqual(report.interaction_kind, "gate_approval", "ambiguous runs must remain clarification/blocked interactions");
      assert.ok(findings.every((finding) => !finding.next_step.includes("--all-active")), "gate-check recovery must not advertise its rejected --all-active option");
    } else {
      assert.ok(findings.some((finding) => finding.next_step.includes("--all-active")), `${target} recovery must retain supported aggregate selection`);
    }
  }
  rmSync(ambiguousRoot, { recursive: true, force: true });

  const legacyRoot = mkdtempSync(join(tmpdir(), "agdf-legacy-"));
  mkdirSync(join(legacyRoot, ".agdf", "control"), { recursive: true });
  writeFileSync(
    join(legacyRoot, ".agdf", "control", "AGDF_RUN.md"),
    "# AGDF Run State\n\n## Run Meta\n\n- run_id: legacy-run\n- mode: structured_delivery\n- current_gate: TP\n- decision: in_progress\n- owner: test-owner\n\n## Objective\n\nLegacy objective\n",
  );
  assert.equal(migrateLegacy(legacyRoot).status, "migrated");
  assert.equal(migrateLegacy(legacyRoot).status, "already_migrated");
  const canonical = join(
    legacyRoot,
    ".agdf",
    "control",
    "runs",
    "legacy-run",
    "RUN_STATE.md",
  );
  const migratedState = parseRunState(readFileSync(canonical, "utf8"), "legacy-run");
  assert.equal(migratedState.meta.current_gate, "TP");
  assert.equal(migratedState.meta.owner, "test-owner");
  writeFileSync(
    join(legacyRoot, ".agdf", "control", "AGDF_RUN.md"),
    renderLegacyProjection(canonical, legacyRoot),
  );
  assert.equal(verifyLegacyProjection(legacyRoot).status, "valid");
  const projectionPath = join(legacyRoot, ".agdf", "control", "AGDF_RUN.md");
  const validProjection = readFileSync(projectionPath, "utf8");
  const lfCanonical = readFileSync(canonical, "utf8");
  const toCrlf = (text) => text.replaceAll("\n", "\r\n");
  writeFileSync(projectionPath, toCrlf(validProjection));
  writeFileSync(canonical, toCrlf(lfCanonical));
  assert.equal(verifyLegacyProjection(legacyRoot).status, "valid", "a CRLF checkout must not report projection drift");
  assert.equal(renderLegacyProjection(canonical, legacyRoot), validProjection, "rendering from a CRLF checkout must produce the LF projection");
  writeFileSync(projectionPath, toCrlf(validProjection.replace("Legacy objective", "Changed projection")));
  assert.equal(verifyLegacyProjection(legacyRoot).status, "legacy_projection_drift", "content drift must stay detectable in a CRLF checkout");
  const crlfDigest = createHash("sha256").update(toCrlf(lfCanonical)).digest("hex");
  writeFileSync(projectionPath, validProjection.replace(/sha256: [0-9a-f]{64}/, `sha256: ${crlfDigest}`));
  writeFileSync(canonical, lfCanonical);
  assert.equal(verifyLegacyProjection(legacyRoot).status, "valid", "a projection rendered from a CRLF checkout must stay valid");
  writeFileSync(
    projectionPath,
    validProjection.replace(/sha256: [0-9a-f]{64}/, `sha256: ${createHash("sha256").update("other").digest("hex")}`),
  );
  assert.equal(verifyLegacyProjection(legacyRoot).status, "legacy_projection_drift", "a foreign digest must still report drift");
  writeFileSync(projectionPath, validProjection);
  writeFileSync(
    projectionPath,
    validProjection.replace("Legacy objective", "Changed projection"),
  );
  assert.equal(
    verifyLegacyProjection(legacyRoot).status,
    "legacy_projection_drift",
  );
  writeFileSync(projectionPath, validProjection);
  writeFileSync(canonical, `${readFileSync(canonical, "utf8")}\nchanged\n`);
  assert.equal(
    verifyLegacyProjection(legacyRoot).status,
    "legacy_projection_drift",
  );
  const beforeFailure = readFileSync(
    join(legacyRoot, ".agdf", "control", "AGDF_RUN.md"),
  );
  assert.throws(
    () => migrateLegacy(legacyRoot, "different-run"),
    /AGDF_RUN_COLLISION|AGDF_LEGACY_ALREADY_PROJECTED/,
  );
  assert.equal(
    readFileSync(join(legacyRoot, ".agdf", "control", "AGDF_RUN.md")).equals(
      beforeFailure,
    ),
    true,
  );
  const injectedRoot = mkdtempSync(join(tmpdir(), "agdf-migration-failure-"));
  mkdirSync(join(injectedRoot, ".agdf", "control"), { recursive: true });
  const injectedLegacyPath = join(injectedRoot, ".agdf", "control", "AGDF_RUN.md");
  const injectedLegacy = "# AGDF Run State\n\n## Objective\n\nFailure injection\n";
  writeFileSync(injectedLegacyPath, injectedLegacy);
  assert.throws(
    () => migrateLegacy(injectedRoot, "injected-run", { readFile: () => "invalid readback" }),
    /AGDF_MIGRATION_VERIFICATION_FAILED/,
  );
  assert.equal(readFileSync(injectedLegacyPath, "utf8"), injectedLegacy);
  assert.equal(discoverRuns(injectedRoot).length, 0);
  rmSync(injectedRoot, { recursive: true, force: true });
  const symlinkRoot = mkdtempSync(join(tmpdir(), "agdf-symlink-"));
  mkdirSync(join(symlinkRoot, ".agdf", "control", "runs"), { recursive: true });
  let symlinkCreatable = true;
  try {
    symlinkSync(
      join(root, ".agdf", "control", "runs", "run-a"),
      join(symlinkRoot, ".agdf", "control", "runs", "linked"),
    );
  } catch (error) {
    if (error.code !== "EPERM") throw error;
    symlinkCreatable = false;
    console.warn(
      "[control-state-test] SKIPPED symlink-rejection assertions: this environment cannot create symlinks (EPERM) without elevated privileges or Windows Developer Mode",
    );
  }
  if (symlinkCreatable) {
    assert.equal(discoverRuns(symlinkRoot)[0].valid, false);
    assert.equal(resolveRuns(symlinkRoot, { allActive: true }).findings[0].code, "AGDF_RUN_PATH_INVALID");
  }
  rmSync(symlinkRoot, { recursive: true, force: true });
  const gitRoot = mkdtempSync(join(tmpdir(), "agdf-git-conflict-"));
  execFileSync("git", ["init", "-q", "--initial-branch=main"], {
    cwd: gitRoot,
  });
  execFileSync("git", ["config", "user.email", "test@example.com"], {
    cwd: gitRoot,
  });
  execFileSync("git", ["config", "user.name", "Test"], { cwd: gitRoot });
  const state = join(gitRoot, "RUN_STATE.md");
  writeFileSync(state, "gate: UR\n");
  execFileSync("git", ["add", "."], { cwd: gitRoot });
  execFileSync("git", ["commit", "-qm", "base"], { cwd: gitRoot });
  execFileSync("git", ["branch", "other"], { cwd: gitRoot });
  writeFileSync(state, "gate: PRD\n");
  execFileSync("git", ["commit", "-qam", "main"], { cwd: gitRoot });
  execFileSync("git", ["checkout", "-q", "other"], { cwd: gitRoot });
  writeFileSync(state, "gate: SD\n");
  execFileSync("git", ["commit", "-qam", "other"], { cwd: gitRoot });
  execFileSync("git", ["checkout", "-q", "main"], { cwd: gitRoot });
  assert.throws(() =>
    execFileSync("git", ["merge", "other"], { cwd: gitRoot, stdio: "pipe" }),
  );
  rmSync(gitRoot, { recursive: true, force: true });
  rmSync(legacyRoot, { recursive: true, force: true });

  // BT-01: Breadcrumb rendering for structured_delivery with 2 approved gates
  {
    const breadcrumb = [
      { gate: "UR", status: "fulfilled" },
      { gate: "PRD", status: "fulfilled" },
      { gate: "SD", status: "current" },
      { gate: "TP", status: "open" },
      { gate: "QA", status: "open" },
      { gate: "UAT", status: "open" },
    ];
    const rendered = buildBreadcrumb(breadcrumb, localeRegistry, "en");
    assert.ok(rendered.includes("\u2713"), "BT-01: fulfilled symbol present");
    assert.ok(rendered.includes("\u25cf"), "BT-01: current symbol present");
    assert.ok(rendered.includes("\u25cb"), "BT-01: open symbol present");
    assert.equal((rendered.match(/\u00b7/g) || []).length, 5, "BT-01: 5 separators for 6 entries");
  }

  // BT-02: Breadcrumb for verified_change
  {
    const breadcrumb = [
      { gate: "UR", status: "fulfilled" },
      { gate: "Verified Change", status: "current" },
      { gate: "OR", status: "open" },
    ];
    const rendered = buildBreadcrumb(breadcrumb, localeRegistry, "en");
    assert.ok(rendered.includes("Verified change"), "BT-02: verified change label present");
    assert.equal((rendered.match(/\u00b7/g) || []).length, 2, "BT-02: 2 separators for 3 entries");
  }

  // BT-03: Post-UR quick_task is presented as Compact Delivery without changing the mode value
  {
    const breadcrumb = [
      { gate: "UR", status: "fulfilled" },
      { gate: "Compact Delivery", status: "current" },
    ];
    const rendered = buildBreadcrumb(breadcrumb, localeRegistry, "en");
    assert.ok(rendered.includes("Compact Delivery"), "BT-03: compact delivery label present");
    assert.equal((rendered.match(/\u00b7/g) || []).length, 1, "BT-03: 1 separator for 2 entries");
  }

  // BT-04: Breadcrumb for block
  {
    const breadcrumb = [
      { gate: "UR", status: "fulfilled" },
      { gate: "Block", status: "current" },
    ];
    const rendered = buildBreadcrumb(breadcrumb, localeRegistry, "en");
    assert.ok(rendered.includes("Block"), "BT-04: block label present");
  }

  // BT-05: Narration for UR
  {
    const narration = buildTransitionNarration("UR", localeRegistry, "en");
    assert.ok(narration.includes("Brownfield Review"), "BT-05: UR narration mentions Brownfield Review");
    assert.ok(narration.includes(localeRegistry.locales.en.primary.narration.noAction), "BT-05: UR narration uses canonical no-action text");
    const transition = postApprovalTransition("Approval: UR");
    assert.equal(transition.internal_next_step, "Brownfield Review and proportional routing");
    assert.equal(transition.user_action_required, "no");
    assert.equal(transition.next_user_gate, "none");
    assert.ok(!transition.allowed_after_approval.includes("PRD"), "BT-05: UR transition does not preselect PRD");
  }

  // BT-06: Narration is a string, not a card object (non-overlap)
  {
    const narration = buildTransitionNarration("UR", localeRegistry, "en");
    assert.equal(typeof narration, "string", "BT-06: narration is a string");
    assert.ok(!narration.includes("Where am I"), "BT-06: narration does not use card three-question form");
  }

  // BT-07: Narration does not contain Approval: value
  {
    const narration = buildTransitionNarration("PRD", localeRegistry, "en");
    assert.ok(!narration.includes("Approval:"), "BT-07: narration does not contain Approval: value");
  }

  // BT-08: Collapse verified_change eligible
  {
    const result = collapseInternalState({ modeSliceDecision: "verified_change", verifiedChangeState: "eligible" }, localeRegistry, "en");
    assert.equal(result.verified_change, "Compact change under review", "BT-08: eligible collapses to under review");
  }

  // BT-09: Collapse verified_change escalated (stays explicit)
  {
    const result = collapseInternalState({ modeSliceDecision: "verified_change", verifiedChangeState: "escalated" }, localeRegistry, "en");
    assert.equal(result.verified_change, "Escalated to structured delivery", "BT-09: escalated stays explicit");
  }

  // BT-10: Collapse context_graph open_gap (stays explicit)
  {
    const result = collapseInternalState({ contextGraphRequiredAction: "open_gap" }, localeRegistry, "en");
    assert.equal(result.context_graph, "Graph gap open", "BT-10: open_gap stays explicit");
  }

  // BT-11: Collapse multi_scope clear (not shown)
  {
    const result = collapseInternalState({ multiScopeState: "clear" }, localeRegistry, "en");
    assert.equal(result.multi_scope, undefined, "BT-11: clear multi_scope not shown");
  }

  // BT-12: collapseInternalState does not mutate input (full projection unchanged)
  {
    const input = { modeSliceDecision: "verified_change", verifiedChangeState: "eligible" };
    collapseInternalState(input, localeRegistry, "en");
    assert.equal(input.modeSliceDecision, "verified_change", "BT-12: input not mutated");
  }

  // BT-14: Locale registry has required new keys for en and de
  {
    for (const locale of ["en", "de"]) {
      assert.ok(localeRegistry.locales[locale].statusCard.breadcrumbFulfilled, `BT-14: ${locale} breadcrumbFulfilled exists`);
      assert.ok(localeRegistry.locales[locale].statusCard.breadcrumbCurrent, `BT-14: ${locale} breadcrumbCurrent exists`);
      assert.ok(localeRegistry.locales[locale].statusCard.breadcrumbOpen, `BT-14: ${locale} breadcrumbOpen exists`);
      assert.ok(localeRegistry.locales[locale].internalStateLabels, `BT-14: ${locale} internalStateLabels exists`);
      assert.ok(localeRegistry.locales[locale].primary.narration, `BT-14: ${locale} narration exists`);
      assert.ok(localeRegistry.locales[locale].gateTitles["Verified Change"], `BT-14: ${locale} Verified Change gateTitle exists`);
      assert.ok(localeRegistry.locales[locale].gateTitles["Quick Task"], `BT-14: ${locale} Quick Task gateTitle exists`);
      assert.ok(localeRegistry.locales[locale].gateTitles["Block"], `BT-14: ${locale} Block gateTitle exists`);
    }
  }

  // IPP-1: run-identity unit matrix and single-owner re-export
  {
    assert.equal(RUN_ID_PATTERN, identityRunIdPattern, "IPP-1: parser re-exports the shared pattern object");
    assert.deepEqual(validateRunIdentity({ runId: "example-run.1", revisionId: "6f0f2f9a-1d0a-4b7e-9c2d-3a5b8c1d2e4f" }), [], "IPP-1: valid identity yields no findings");
    for (const runId of ["Example", ".leading-dot", "", `a${"b".repeat(128)}`, "spaced id"]) {
      assert.deepEqual(validateRunIdentity({ runId, revisionId: "6f0f2f9a-1d0a-4b7e-9c2d-3a5b8c1d2e4f" }).map((finding) => finding.code), ["AGDF_RUN_ID_INVALID"], `IPP-1: run_id ${JSON.stringify(runId)} is invalid`);
    }
    for (const revisionId of ["", "not-a-uuid", "6f0f2f9a-1d0a-4b7e-9c2d"]) {
      assert.deepEqual(validateRunIdentity({ runId: "example", revisionId }).map((finding) => finding.code), ["AGDF_RUN_REVISION_ID_INVALID"], `IPP-1: revision_id ${JSON.stringify(revisionId)} is invalid`);
    }
    assert.deepEqual(validateRunIdentity({}).map((finding) => finding.code), ["AGDF_RUN_ID_INVALID", "AGDF_RUN_REVISION_ID_INVALID"], "IPP-1: missing identity yields both findings");
  }

  // IPP-2 / IPP-3: legacy content path yields doctor identity findings and a loud gate-check outcome
  {
    const identityRoot = mkdtempSync(join(tmpdir(), "agdf-identity-parity-"));
    try {
      execFileSync(process.execPath, [cli, "init", "--dir", identityRoot]);
      rmSync(join(identityRoot, ".agdf", "control", "runs"), { recursive: true, force: true });
      const legacyState = `# AGDF Run State\n\n## Run Meta\n\n- run_id: Bad Run\n- lifecycle: active\n- current_gate: UR\n\n## Current Control State\n\n| Question | Answer |\n|---|---|\n| What is known? | Legacy fixture without identity. |\n| What is the next allowed action? | Draft the UR. |\n\n## Evidence\n\n| Evidence | Source | Covers | Strength |\n|---|---|---|---|\n| Fixture | identity-parity-test | legacy path | direct |\n\n## Closeout\n\n- next_allowed_action: Draft the UR.\n`;
      writeFileSync(join(identityRoot, ".agdf", "control", "AGDF_RUN.md"), legacyState, "utf8");
      const doctorResult = spawnSync(process.execPath, [cli, "doctor", "--dir", identityRoot, "--json"], { encoding: "utf8" });
      const doctorReport = JSON.parse(doctorResult.stdout);
      const doctorCodes = doctorReport.findings.map((finding) => finding.code);
      assert.ok(doctorCodes.includes("AGDF_RUN_ID_INVALID"), "IPP-2: doctor reports invalid run_id on the legacy content path");
      assert.ok(doctorCodes.includes("AGDF_RUN_REVISION_ID_INVALID"), "IPP-2: doctor reports missing revision_id on the legacy content path");
      for (const finding of doctorReport.findings.filter((entry) => ["AGDF_RUN_ID_INVALID", "AGDF_RUN_REVISION_ID_INVALID"].includes(entry.code))) {
        assert.equal(finding.severity, "revise", `IPP-2: ${finding.code} severity is revise`);
        assert.match(finding.next_step, /run-migrate/, `IPP-2: ${finding.code} names the repair path`);
      }
      assert.notEqual(doctorReport.status, "warn", "IPP-2: identity defects are never reported as mere warn");

      const gateResult = spawnSync(process.execPath, [cli, "gate-check", "--dir", identityRoot, "--json"], { encoding: "utf8" });
      const gateReport = JSON.parse(gateResult.stdout);
      assert.ok(["AGDF_RUN_ID_INVALID", "AGDF_RUN_REVISION_ID_INVALID", "AGDF_RUN_SEAL_INVALID"].includes(gateReport.blocking_reason), "IPP-3: gate-check blocks an unsealed legacy identity instead of silently dropping the card");
      assert.match(gateReport.next_allowed_action, /run-migrate|legacy migration|Fill the current UR control state/, "IPP-3: gate-check names a concrete repair action");
    } finally {
      rmSync(identityRoot, { recursive: true, force: true });
    }
  }

  // IPP-4: healthy canonical run renders cards without presentation diagnostics
  {
    const healthyRoot = mkdtempSync(join(tmpdir(), "agdf-identity-healthy-"));
    try {
      execFileSync(process.execPath, [cli, "init", "--dir", healthyRoot]);
      execFileSync(process.execPath, [cli, "run-create", "--dir", healthyRoot, "--run", "identity-healthy-run"]);
      const gateResult = spawnSync(process.execPath, [cli, "gate-check", "--dir", healthyRoot, "--run", "identity-healthy-run", "--json"], { encoding: "utf8" });
      const gateReport = JSON.parse(gateResult.stdout);
      assert.ok(gateReport.status_presentation?.markdown, "IPP-4: healthy run renders the status card");
      assert.equal("presentation_diagnostics" in gateReport, false, "IPP-4: healthy run report has no presentation_diagnostics key");
    } finally {
      rmSync(healthyRoot, { recursive: true, force: true });
    }
  }

  // Sealed runs: run-update records edits as revisions, run-approve alone changes approvals.
  {
    const recordingRoot = mkdtempSync(join(tmpdir(), "agdf-run-recording-"));
    try {
      initializeCanonicalControl(recordingRoot, generatedFilesForTarget("init", recordingRoot, false, "de"));
      const statePath = createRun(recordingRoot, "rec");
      const read = () => readFileSync(statePath, "utf8");
      const meta = () => parseRunState(read(), "rec").meta;
      const gate = () => evaluateGateCheck(recordingRoot, { runId: "rec" });
      const approve = (overrides = {}) => approveRunGate(recordingRoot, {
        runId: "rec",
        gate: "UR",
        revisionId: meta().revision_id,
        response: "Approval: UR",
        date: "2026-01-02",
        ...overrides,
      }, { evaluateGateCheck });

      assert.equal(runSealState(recordingRoot, read()).status, "valid", "run-create writes a sealed run");
      for (const heading of ["Approvals", "Artefacts", "Mode/Slice Decision", "Artefact Chain", "Evidence", "Closeout"]) {
        assert.match(read(), new RegExp(`^## ${heading}$`, "m"), `run-create writes the ${heading} section`);
      }
      assert.match(read(), /^\| UR \| missing \|  \|$/m);
      const fresh = gate();
      assert.equal(fresh.status, "open");
      assert.equal(fresh.missing_approval, "Approval: UR");
      assert.equal(fresh.approval_presentation, null, "no approval is presented before the UR artefact exists");
      assert.equal(approve().reason, "approval_presentation_unavailable");

      mkdirSync(join(recordingRoot, ".agdf", "control", "artefacts", "rec"), { recursive: true });
      const urPath = join(recordingRoot, ".agdf", "control", "artefacts", "rec", "UR.md");
      writeFileSync(urPath, "# UR: Recording\r\n\r\nStatus: draft\r\n\r\n## Problem\r\nA recorded UR needs a visible problem statement. The user should review this document before approval.\r\n\r\n## AGDF Approval Summary (de; source=en)\r\n- Problem: Ein dauerhaftes UR braucht ein sichtbares Problem.\r\n- Ziel: Das gespeicherte UR vor der Entscheidung prüfen.\r\n- Umfang: Eine kurze, nachvollziehbare Nutzeranforderung.\r\n");
      writeFileSync(statePath, read().replace("| UR |  | missing |  |", "| UR | `.agdf/control/artefacts/rec/UR.md` | draft |  |"));
      assert.equal(runSealState(recordingRoot, read()).status, "content_changed");
      const unrecorded = gate();
      assert.equal(unrecorded.blocking_reason, "AGDF_RUN_SEAL_MISMATCH");
      assert.equal(unrecorded.approval_presentation, null);
      assert.ok(unrecorded.status_presentation?.markdown, "the localized card renders the run-update recovery");
      assert.equal(recordRunRevision(recordingRoot, { runId: "rec", revisionId: "not-current" }).reason, "stale_revision");
      const first = meta();
      const updated = recordRunRevision(recordingRoot, { runId: "rec", revisionId: first.revision_id });
      assert.equal(updated.outcome, "updated");
      assert.equal(updated.revision, "2");
      assert.notEqual(updated.revision_id, first.revision_id);
      assert.equal(recordRunRevision(recordingRoot, { runId: "rec", revisionId: updated.revision_id }).outcome, "unchanged");

      writeFileSync(urPath, "# UR: Recording\n\nStatus: draft\n\n## Problem\nA recorded UR needs a visible problem statement. The user should review this document before approval.\n\n## AGDF Approval Summary (de; source=en)\n- Problem: Ein dauerhaftes UR braucht ein sichtbares Problem.\n- Ziel: Das gespeicherte UR vor der Entscheidung prüfen.\n- Umfang: Eine kurze, nachvollziehbare Nutzeranforderung.\n");
      const lfState = read();
      writeFileSync(statePath, lfState.replace(/\n/g, "\r\n"));
      assert.equal(runSealState(recordingRoot, read()).status, "valid", "line-ending conversion keeps the seal valid");
      writeFileSync(statePath, lfState);
      const recordedGate = gate();
      assert.equal(recordedGate.approval_presentation?.revision_id, updated.revision_id, JSON.stringify(recordedGate.presentation_diagnostics));

      assert.equal(approve({ response: "passt schon" }).reason, "wrong_or_non_approval_response");
      assert.equal(approve({ response: "Approval: PRD" }).reason, "wrong_or_non_approval_response");
      assert.equal(approve({ revisionId: first.revision_id }).reason, "stale_revision");
      assert.equal(approve({ gate: "PRD", response: "Approval: PRD" }).reason, "gate_not_ready");
      assert.equal(approve({ gate: "Brownfield Review" }).reason, "gate_invalid");
      assert.equal(meta().revision_id, updated.revision_id, "rejected approvals write nothing");

      const recorded = read();
      writeFileSync(statePath, recorded.replace("| UR | missing |  |", "| UR | approved | Approval: UR |"));
      assert.equal(gate().blocking_reason, "AGDF_RUN_APPROVALS_UNRECORDED");
      assert.equal(recordRunRevision(recordingRoot, { runId: "rec", revisionId: updated.revision_id }).reason, "approvals_unrecorded");
      writeFileSync(statePath, recorded.replace("| PRD | missing |  |", "| PRD | not_applicable | skipped |"));
      assert.equal(recordRunRevision(recordingRoot, { runId: "rec", revisionId: updated.revision_id }).reason, "approvals_unrecorded", "skipping a gate by hand is an approval change");
      writeFileSync(statePath, recorded);

      assert.equal(approve().reason, "presentation_required", "an unbound valid reply cannot approve");
      const prepared = prepareRunPresentation(recordingRoot, { runId: "rec", gate: "UR", revisionId: meta().revision_id }, { evaluateGateCheck });
      assert.equal(prepared.outcome, "prepared");
      const approved = approve({ presentationId: prepared.presentation_id });
      assert.equal(approved.outcome, "approved");
      assert.equal(approved.previous_revision_id, updated.revision_id);
      assert.equal(approved.revision, "3");
      assert.equal(approved.next_gate_after_approval, "Brownfield Review");
      const approvedState = read();
      const approvedControl = parseControlState(approvedState, { userGates: ["UR", "PRD", "SD", "TP", "QA", "UAT"], internalSteps: ["Brownfield Review", "CR"], closeoutArtefacts: ["OR"] });
      assert.equal(parseRunState(approvedState).meta.current_gate, "Brownfield Review", "approval advances the persisted run meta to the canonical next gate");
      assert.equal(approvedControl.approvals.get("UR")?.status, "approved");
      assert.match(approvedState, /^\| What is missing\? \| No approval is pending\. \|$/m);
      assert.match(approvedState, /^\| What is the next allowed action\? \| Run Brownfield Review after G-00 before drafting PRD, or mark Brownfield Review not_applicable with evidence\. \|$/m);
      assert.match(approvedState, /^- next_allowed_action: Run Brownfield Review after G-00 before drafting PRD, or mark Brownfield Review not_applicable with evidence\.$/m);
      assert.match(approvedState, /^\| UR \| approved \| `Approval: UR` · 2026-01-02 · revision 2 · `\.agdf\/control\/artefacts\/rec\/UR\.md` sha256:[0-9a-f]{16} · presentation [0-9a-f-]{36} sha256:[0-9a-f]{64} \|$/m);
      assert.match(approvedState, /^\| UR \| `\.agdf\/control\/artefacts\/rec\/UR\.md` \| approved \|  \|$/m);
      assert.match(approvedState, /^\| UR \| approved_by \| Approval: UR \| `Approval: UR` · 2026-01-02 · revision 2 /m);
      assert.equal(runSealState(recordingRoot, approvedState).status, "valid");
      const afterApproval = gate();
      assert.equal(afterApproval.status, "open");
      assert.equal(afterApproval.current_gate, "Brownfield Review");
      assert.ok(afterApproval.status_presentation?.markdown, "the localized card renders after run-approve");
      assert.equal(approve({ revisionId: approved.revision_id }).reason, "gate_not_ready", "an approval is recorded once");

      writeFileSync(statePath, approvedState.replace(/^- approval_seal:.*\n/m, ""));
      assert.equal(runSealState(recordingRoot, read()).status, "invalid");
      assert.equal(gate().blocking_reason, "AGDF_RUN_SEAL_INVALID");
      assert.equal(recordRunRevision(recordingRoot, { runId: "rec", revisionId: approved.revision_id }).reason, "seal_invalid");
    } finally {
      rmSync(recordingRoot, { recursive: true, force: true });
    }
  }

  // run-step records the small path in single sealed revisions, including the backlog pointer.
  {
    const stepRoot = mkdtempSync(join(tmpdir(), "agdf-run-step-"));
    try {
      initializeCanonicalControl(stepRoot, generatedFilesForTarget("init", stepRoot, false, "de"));
      const statePath = createRun(stepRoot, "step");
      const read = () => readFileSync(statePath, "utf8");
      const revision = () => parseRunState(read(), "step").meta.revision_id;
      const artefacts = join(stepRoot, ".agdf", "control", "artefacts", "step");
      const backlog = () => readFileSync(join(stepRoot, ".agdf", "control", "MASTER_BACKLOG.md"), "utf8");
      const step = (name, fields = {}) => recordRunStep(stepRoot, { runId: "step", revisionId: revision(), step: name, ...fields }, { policy: policyForRunContent, date: "2026-01-03" });

      assert.equal(step("unknown").reason, "step_invalid");
      assert.equal(recordRunStep(stepRoot, { runId: "step", revisionId: "stale", step: "ur", title: "x" }, { policy: policyForRunContent }).reason, "stale_revision");
      assert.equal(step("ur", { title: "subtract" }).reason, "artefact_missing");
      mkdirSync(artefacts, { recursive: true });
      writeFileSync(join(artefacts, "UR.md"), "# UR: subtract\n\n## Problem\nA small numeric change is needed. The user should review this document before approval.\n\n## AGDF Approval Summary (de; source=en)\n- Problem: Ein dauerhaftes UR braucht ein sichtbares Problem.\n- Ziel: Das gespeicherte UR vor der Entscheidung prüfen.\n- Umfang: Eine kurze, nachvollziehbare Nutzeranforderung.\n");
      assert.equal(step("ur").reason, "title_missing");
      const drafted = step("ur", { title: "subtract | with test" });
      assert.equal(drafted.outcome, "recorded");
      assert.equal(drafted.current_gate, "UR");
      assert.equal(drafted.backlog, "updated");
      assert.match(read(), /^\| UR \| `\.agdf\/control\/artefacts\/step\/UR\.md` \| draft \|  \|$/m);
      assert.match(read(), /^\| What is missing\? \| Exact Approval: UR\. \|$/m);
      assert.match(backlog(), /^\| P1 \| step \| subtract \/ with test \| Needs UR \| \[UR\]\(artefacts\/step\/UR\.md\) \| \[UR\]\(artefacts\/step\/UR\.md\) \| /m);
      assert.equal(runSealState(stepRoot, read()).status, "valid");
      const drafting = evaluateGateCheck(stepRoot, { runId: "step" });
      assert.equal(drafting.approval_presentation?.revision_id, revision(), "the recorded UR is ready for its exact approval");
      assert.equal(evaluateDoctor(stepRoot, { runId: "step" }).findings.some((finding) => finding.code === "AGDF_BACKLOG_POINTER_EMPTY"), false);

      assert.equal(step("route", { route: "quick_task", reason: "r", evidence: "e" }).reason, "artefact_missing");
      writeFileSync(join(artefacts, "BROWNFIELD_REVIEW.md"), "# Brownfield Review: subtract\n");
      assert.equal(step("route", { route: "tiny", reason: "r", evidence: "e" }).reason, "route_invalid");
      assert.equal(step("route", { route: "quick_task", reason: "r" }).reason, "route_reason_missing");
      const routed = step("route", { route: "quick_task", reason: "additive function in one module", evidence: "math.js only" });
      assert.equal(routed.current_gate, "UR", "pre-approval routing keeps the exact UR approval as the next user gate");
      assert.match(read(), /^- mode: quick_task$/m);
      assert.match(read(), /^- required_next_gate: Quick Task Execution$/m);
      assert.equal(approveRunGate(stepRoot, { runId: "step", gate: "UR", revisionId: revision(), response: "Approval: UR", presentationId: prepareRunPresentation(stepRoot, { runId: "step", gate: "UR", revisionId: revision() }, { evaluateGateCheck }).presentation_id, date: "2026-01-03" }, { evaluateGateCheck }).outcome, "approved");
      assert.equal(evaluateGateCheck(stepRoot, { runId: "step" }).current_gate, "Quick Task Execution", "the recorded route is applied immediately after UR approval");
      assert.equal(step("closeout", { result: "r", evidence: "e", risk: "none", next: "none" }).reason, "code_review_missing");
      assert.match(backlog(), /\| Quick Task Execution work pending \| \[UR\]\(artefacts\/step\/UR\.md\) · \[Brownfield\]\(artefacts\/step\/BROWNFIELD_REVIEW\.md\) \|/);

      assert.equal(step("evidence").reason, "evidence_missing");
      assert.equal(step("evidence", { evidence: "npm test: 2 pass", source: "npm test" }).outcome, "recorded");
      assert.equal(step("closeout", { result: "r", evidence: "e", risk: "none", next: "none" }).reason, "code_review_missing", "Code Review stays mandatory");
      assert.equal(step("review", { decision: "maybe", evidence: "e" }).reason, "decision_invalid");
      assert.equal(step("review", { decision: "pass", evidence: "diff limited to subtract" }).outcome, "recorded");
      assert.equal(step("closeout", { result: "r", evidence: "e" }).reason, "closeout_fields_missing");
      const closed = step("closeout", { result: "subtract added with tests", evidence: "npm test: 2 pass", risk: "none", next: "Commit on request" });
      assert.equal(closed.current_gate, "OR");
      assert.match(readFileSync(join(artefacts, "OR.md"), "utf8"), /^# OR-lite: subtract$/m);
      assert.match(read(), /^- lifecycle: completed$/m);
      assert.doesNotMatch(backlog(), /^\| P1 \| step \|/m, "the active pointer moves to completed");
      assert.match(backlog(), /^\| step \| subtract \/ with test \| Completed \| \[OR\]\(artefacts\/step\/OR\.md\) \| subtract added with tests \|$/m);
      assert.equal(runSealState(stepRoot, read()).status, "valid");
      const done = evaluateGateCheck(stepRoot, { runId: "step" });
      assert.equal(done.status, "pass");
      assert.ok(done.status_presentation?.markdown, "the German card renders after closeout");
      assert.deepEqual(evaluateDoctor(stepRoot, { runId: "step" }).findings.filter((finding) => finding.severity !== "warn"), []);
      assert.equal(step("closeout", { result: "r", evidence: "e", risk: "none", next: "none" }).reason, "gate_not_ready", "a closed run cannot close twice");
    } finally {
      rmSync(stepRoot, { recursive: true, force: true });
    }
  }

  console.log("control-state tests passed");

  const awaitingOrFindings = [];
  const normalizedAwaitingOr = normalizeBacklogStatus("Awaiting OR", awaitingOrFindings, "test-backlog.md");
  assert.equal(normalizedAwaitingOr, "awaiting_or", "BT-15: Awaiting OR normalizes to awaiting_or");
  assert.equal(awaitingOrFindings.length, 0, "BT-15: Awaiting OR produces no findings");

  console.log("backlog status vocabulary tests passed");
} finally {
  rmSync(root, { recursive: true, force: true });
}
