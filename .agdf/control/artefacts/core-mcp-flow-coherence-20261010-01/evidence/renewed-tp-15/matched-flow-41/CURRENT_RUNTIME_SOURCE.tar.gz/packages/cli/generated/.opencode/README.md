# AGDF OpenCode surface

These files were generated from the AGDF source repository for OpenCode.

- The globally installed npm plugin `create-agdf` owns the shared OpenCode runtime surface.
- A repository is AGDF-active when `.agdf/control/config.json` is valid; this activation does not copy `.opencode/` assets.
- Global adapters use `agdf-global-*` to avoid same-name masking by supported legacy local `agdf-*` skills.
- The eager `AGDF.md` is a micro-bootstrap; `agdf-agent-router.md` retains the full on-demand router.
- Preserve an explicit user `permission.question: deny`; AGDF then uses exact textual approval and never interprets OpenCode permission outcomes or auto mode as gate authority.
- After positive Request Activation selects actual delivery work, load `agdf-global-gate-check` through OpenCode's native `skill` tool. Unclear approval alone never activates AGDF.
- Use `npx --yes @agdf/cli@latest opencode-status --json` to distinguish global hook/native-skill configuration, package loadability, durable activation, legacy compatibility and session activity.
- For a read-only ready-gate preview, use installed `agdf gate-check --approval-envelope`; prepare the actual approval with `run-present` before asking the user. Reserve `agdf gate-check --json` for native-adapter input, automation or audit evidence and use `npx ...@latest` only for bootstrap, refresh or a missing local executable.
- The globally installed runtime contract is the shared gate and output contract.

## Skills

- `agdf-brownfield-analysis`
- `agdf-clean-implementation-review`
- `agdf-code-review`
- `agdf-delivery-closeout`
- `agdf-delivery-path-search`
- `agdf-gate-check`
- `agdf-prd-definition`
- `agdf-qa-gate`
- `agdf-release-or`
- `agdf-sd-definition`
- `agdf-task-plan-review`
- `agdf-ur-definition`
- `agdf-ux-intent-definition`
