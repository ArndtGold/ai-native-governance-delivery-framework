# AGDF Runtime Contract

This manifest indexes the thematic runtime-contract modules used by AGDF skills and runtime validation.

<!-- AGDF-RUNTIME-CONTRACT-MODULES:START -->
| Module | Path | Coverage |
|---|---|---|
| Request Activation | `contracts/request-activation.md` | Canonical focused module; follow the linked source for semantics. |
| Task Target Resolution | `contracts/task-target-resolution.md` | Canonical focused module; follow the linked source for semantics. |
| Gate Transition | `contracts/gate-transition.md` | Canonical focused module; follow the linked source for semantics. |
| Gate Artifact Preparation | `contracts/gate-artifact-preparation.md` | Canonical focused module; follow the linked source for semantics. |
| Interaction | `contracts/interaction.md` | Canonical focused module; follow the linked source for semantics. |
| Modes | `contracts/modes.md` | Canonical focused module; follow the linked source for semantics. |
| Quality | `contracts/quality.md` | Canonical focused module; follow the linked source for semantics. |
| Context Graph | `contracts/context-graph.md` | Canonical focused module; follow the linked source for semantics. |
| Control Scaffold | `contracts/control-scaffold.md` | Canonical focused module; follow the linked source for semantics. |
| Closeout | `contracts/closeout.md` | Canonical focused module; follow the linked source for semantics. |
| UR Definition | `contracts/ur-definition.md` | Canonical focused module; follow the linked source for semantics. |
| PRD Definition | `contracts/prd-definition.md` | Canonical focused module; follow the linked source for semantics. |
| SD Definition | `contracts/sd-definition.md` | Canonical focused module; follow the linked source for semantics. |
<!-- AGDF-RUNTIME-CONTRACT-MODULES:END -->

The explanatory framework lives in `docs/`, the operating philosophy in `plugins/agdf/meta/agdf-constitution.md`, and the principles in `plugins/agdf/meta/agdf-tenets.md`.
