# AGDF Public Plugin Readiness

- release: `0.14.5`
- candidate_state: `repository_ready`
- submission_ready: `false`

## Evidence classes

| Class | State | Detail |
|---|---|---|
| repository | pass | canonical contract and deterministic source checks |
| bundle | pass | 60 inventoried files; inventory digest 3e6fce01b3d44b6bc530d117a51308c04fb4895898cf8c8272e0bedbced15833 |
| installed_host | unverified | PPD-L02 and PPD-L03 not performed |
| portal | unverified | unverified |
| post_publication | unverified | not published |

## Submission blockers

- publisher identity and Apps Management authority are unverified
- availability selection is pending
- public deployment and exact-host evidence are unverified
- portal draft has not been created or reconciled

Repository and bundle evidence do not prove installation, authenticated host behavior, publisher identity, portal state, deployment or publication.
