# OR-lite: Synthetic subtraction
Report mode: OR-lite
Run: quick-closeout
## Result
Synthetic bounded operation and regression complete.
## Evidence
Disposable synthetic result.
## Risk
none
## Next Step
No automatic VCS action.
