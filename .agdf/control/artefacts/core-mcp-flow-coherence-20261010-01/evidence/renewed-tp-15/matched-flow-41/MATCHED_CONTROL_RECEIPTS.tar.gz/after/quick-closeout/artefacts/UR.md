# UR: Synthetic subtraction
## Problem
One bounded subtraction operation is missing.
## Goal
Provide the operation with a direct regression.
## Scope
One function and its test.
