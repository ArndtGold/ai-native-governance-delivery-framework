# AGDF Run State

## Run Meta

- control_state_version: 2
- run_id: quick-closeout
- lifecycle: completed
- revision: 6
- revision_id: a0f6962a-d90f-4a84-9342-bc9eb9804772
- content_seal: sha256:3b34284e85c1439bfe81d6306cca7f9e9b86da117a971649f4b611d7c3bd7273
- approval_seal: sha256:f2369b4b934ce43eae4c8d178db249569f4333024a19168f069a0931198700d5
- updated_at: 2026-10-12T16:15:23.999Z
- mode: quick_task
- current_gate: OR
- decision: completed
- owner: agent

## Objective

Describe the trustworthy outcome.

## Current Control State

| Question | Answer |
|---|---|
| What is known? | Run delivery completed; exact OR-lite at .agdf/control/artefacts/quick-closeout/OR.md. |
| What is approved? | Approval: UR |
| What is missing? | No approval is pending. |
| What is the next allowed action? | Run completed; prepare a VCS handoff only when explicitly requested. |
| What is explicitly forbidden right now? | repeat completed Run work; perform VCS or release actions automatically |

## Approvals

| Gate | Status | Evidence |
|---|---|---|
| UR | approved | `Approval: UR` · 2026-10-12 · revision 3 · `.agdf/control/artefacts/quick-closeout/UR.md` sha256:57e586c910e91253 · presentation c7dd0e7d-2299-469f-9a48-4a2370325300 sha256:2c833985b3588574f0f6fafcf81ea04004feb13c75aea16da87d3476ef5359f3 |
| PRD | missing |  |
| SD | missing |  |
| TP | missing |  |
| QA | missing |  |
| UAT | missing |  |

## Artefacts

| Type | Path | Status | Notes |
|---|---|---|---|
| UR | `.agdf/control/artefacts/quick-closeout/UR.md` | approved |  |
| Brownfield Review | `.agdf/control/artefacts/quick-closeout/BROWNFIELD_REVIEW.md` | done |  |
| Verified Change |  | missing |  |
| PRD |  | missing |  |
| SD |  | missing |  |
| TP |  | missing |  |
| Brownfield Analysis |  | missing |  |
| CD+Tests |  | missing |  |
| CR | .agdf/control/artefacts/quick-closeout/CODE_REVIEW.md | done | Bound actual Code Review result |
| QA |  | missing |  |
| OR | .agdf/control/artefacts/quick-closeout/OR.md | done | Bound exact orchestration report |

## Mode/Slice Decision

- decision: quick_task
- required_next_gate: Quick Task Execution
- scope_reason: One bounded function and its direct regression
- evidence: .agdf/control/artefacts/quick-closeout/BROWNFIELD_REVIEW.md

## Artefact Chain

| From | Relationship | To | Evidence |
|---|---|---|---|
| UR | approved_by | Approval: UR | `Approval: UR` · 2026-10-12 · revision 3 · `.agdf/control/artefacts/quick-closeout/UR.md` sha256:57e586c910e91253 · presentation c7dd0e7d-2299-469f-9a48-4a2370325300 sha256:2c833985b3588574f0f6fafcf81ea04004feb13c75aea16da87d3476ef5359f3 |

## Evidence

| Evidence | Source | Covers | Strength |
|---|---|---|---|
| Run creation | run-create | Control initialization | direct |
| UR draft | `.agdf/control/artefacts/quick-closeout/UR.md` | problem, goal, scope and acceptance signals | direct |
| Brownfield Review | `.agdf/control/artefacts/quick-closeout/BROWNFIELD_REVIEW.md` | Mode/Slice Decision `quick_task` | direct |
| Code Review | code-review | decision pass: .agdf/control/artefacts/quick-closeout/CR.md | direct |
| OR | .agdf/control/artefacts/quick-closeout/OR.md | selected Run closeout; no VCS or publication effect | bound cooperative result |

## Closeout

- next_allowed_action: Run completed; prepare a VCS handoff only when explicitly requested.
- quality_outlook:

## Approval Operations

- schema_version: 1

| operation_id | request_digest | receipt |
|---|---|---|
| 7a53c49f-c34b-421c-a9ef-d9bb5daf48d9 | sha256:c0fc81dffc34d5683cfd9f949c9c99bf77e4afbfce638f32d9fe4b2bafdf8f40 | eyJhY3Rpb24iOiJyZWNvcmRfZ2F0ZV9hcHByb3ZhbCIsImFzc3VyYW5jZSI6eyJpbmRlcGVuZGVudF9odW1hbl9wcm9vZiI6InVuYXZhaWxhYmxlIiwibGFuZSI6ImNvb3BlcmF0aXZlX2xvY2FsIiwicmVwbHlfcHJvdmVuYW5jZSI6ImNhbGxlcl9mb3J3YXJkZWRfZGVsaWJlcmF0ZV9yZXBseSJ9LCJiaW5kaW5nIjp7ImV4cGVjdGVkX3JldmlzaW9uX2lkIjoiYTMzMTY4YWMtMTE3OC00YjBmLWJlYmYtMTRhZmUyNDU4MzUwIiwiZ2F0ZSI6IlVSIiwicHJlc2VudGF0aW9uX2lkIjoiYzdkZDBlN2QtMjI5OS00NjlmLTlhNDgtNGEyMzcwMzI1MzAwIiwicnVuX2lkIjoicXVpY2stY2xvc2VvdXQiLCJ0YXJnZXRfaWQiOiJzaGEyNTY6YzcwMTM1MTc3ODZjMGEyMWFlYWY3YTM4MjAyYjUzMzQ2NGVlMWFjYjQxYjMzOGNhZDM1OTJjMjJiNGZhMGRhZCJ9LCJjb21tYW5kX2RpZ2VzdCI6bnVsbCwiY3JlYXRlZF9hdCI6IjIwMjYtMTAtMTJUMTY6MTU6MjMuMDc4WiIsImVmZmVjdCI6eyJhbGxvd2VkX2FmdGVyX2FwcHJvdmFsIjoiUHJvY2VlZCBhcyBhIFF1aWNrIFRhc2sgd2l0aGluIHRoZSBCcm93bmZpZWxkIFJldmlldyBzY29wZSBhbmQgcmVjb3JkIHZlcmlmaWNhdGlvbiBldmlkZW5jZS4iLCJhcHByb3ZhbCI6IkFwcHJvdmFsOiBVUiIsImFydGVmYWN0X2RpZ2VzdCI6InNoYTI1Njo1N2U1ODZjOTEwZTkxMjUzY2YwMjFkNzI2ZDBmMjMzMDJhNmE5ZGM3NTcxOGUxNDdhZmJkMjI3MGM5YWFmZjIwIiwiZ2F0ZSI6IlVSIiwibWF0ZXJpYWxfc291cmNlcyI6W3siZGlnZXN0Ijoic2hhMjU2OjU3ZTU4NmM5MTBlOTEyNTNjZjAyMWQ3MjZkMGYyMzMwMmE2YTlkYzc1NzE4ZTE0N2FmYmQyMjcwYzlhYWZmMjAiLCJwYXRoIjoiLmFnZGYvY29udHJvbC9hcnRlZmFjdHMvcXVpY2stY2xvc2VvdXQvVVIubWQiLCJ0eXBlIjoiVVIifV0sIm1hdGVyaWFsX3ZlcnNpb24iOiJzaGEyNTY6MGYxNWM3YTc4OGUwNjVhNGZhYTk4ODNiZmVkOWFkNjZkZjQ0ZjI2ZjEwMGYwOGRhZjM4Y2EwNmMzYWY1MzkzNSIsIm5leHRfZ2F0ZV9hZnRlcl9hcHByb3ZhbCI6IlF1aWNrIFRhc2sgRXhlY3V0aW9uIiwicHJlc2VudGF0aW9uX2RpZ2VzdCI6InNoYTI1NjoyYzgzMzk4NWIzNTg4NTc0ZjBmNmZhZmNmODFlYTA0MDA0ZmViMTNjNzVhZWExNmRhODdkMzQ3NmVmNTM1OWYzIiwicHJldmlvdXNfcmV2aXNpb25faWQiOiJhMzMxNjhhYy0xMTc4LTRiMGYtYmViZi0xNGFmZTI0NTgzNTAiLCJyZXN1bHRpbmdfcmV2aXNpb25faWQiOiIzYTVmYjhkZS02NzA0LTQ4MWUtYTRjZC1mNTI2YTZiNzMyNTciLCJyZXZpc2lvbiI6NH0sIm9wZXJhdGlvbl9pZCI6IjdhNTNjNDlmLWMzNGItNDIxYy1hOWVmLWQ5YmI1ZGFmNDhkOSIsInByb2R1Y2VyIjp7ImNvbnRyYWN0IjoiYXBwcm92YWwtc2VydmljZS8xIiwicGFja2FnZV92ZXJzaW9uIjoiMC4xNC41In0sInJlcXVlc3RfZGlnZXN0Ijoic2hhMjU2OmMwZmM4MWRmZmMzNGQ1NjgzY2ZkOWY5NDljOWM5OWJmNzdlNGFmYmZjZTYzOGYzMmQ5ZmU0YjJiYWZkZjhmNDAiLCJzY2hlbWFfdmVyc2lvbiI6IjIifQ |

## Run Operations

- schema_version: 1

| operation_id | request_digest | receipt |
|---|---|---|
| 3106528b-c4ed-4149-9815-8c05088732d5 | sha256:7d9a7f7e3bf5f5d4c47fdd5dcd5dcde795da45a157cc28c614408015a1f170c9 | eyJhc3N1cmFuY2UiOnsiaW5kZXBlbmRlbnRfaHVtYW5fcHJvb2YiOiJ1bmF2YWlsYWJsZSIsImxhbmUiOiJjb29wZXJhdGl2ZV9sb2NhbCIsInJlcGx5X3Byb3ZlbmFuY2UiOiJjYWxsZXJfZm9yd2FyZGVkX2RlbGliZXJhdGVfcmVwbHkifSwiY3JlYXRlZF9hdCI6IjIwMjYtMTAtMTJUMTY6MTU6MjMuNjM4WiIsImVmZmVjdCI6eyJwcmV2aW91c19yZXZpc2lvbl9pZCI6IjNhNWZiOGRlLTY3MDQtNDgxZS1hNGNkLWY1MjZhNmI3MzI1NyIsInJlY29yZCI6eyJjb3ZlcnMiOiJzZWxlY3RlZCBSdW4gc2NvcGUiLCJzb3VyY2UiOnsiZGlnZXN0Ijoic2hhMjU2OjJhZGNmMDZhYWJkZmE3MjdjMzk2ZjliZTJhNzRmMWFhMTYzZTQwYzU3Y2FiNzU3MjhkYzc3OGY4YzA5OWE3NTkiLCJwYXRoIjoiLmFnZGYvY29udHJvbC9hcnRlZmFjdHMvcXVpY2stY2xvc2VvdXQvQ09ERV9SRVZJRVcubWQifSwic291cmNlX3NldF9kaWdlc3QiOiJzaGEyNTY6NzQ5ZGI5MzM4YzNkOTdmNmUyZTBiM2E5ZDIxZjcwZTUwZGNhZWJjNzc3MDk2MDdlMzJkODIyZmFjMWY2MGQ5YyIsInN0YXR1cyI6ImRvbmUiLCJzdGVwIjoicmV2aWV3In0sInJlc3VsdGluZ19yZXZpc2lvbl9pZCI6Ijc1YTYxOTc0LTA3YjktNDhmNS1hNjk5LTUxY2YyYTU5YWM2YiIsInJldmlzaW9uIjo1fSwiZXhwZWN0ZWRfcmV2aXNpb25faWQiOiIzYTVmYjhkZS02NzA0LTQ4MWUtYTRjZC1mNTI2YTZiNzMyNTciLCJraW5kIjoic3RlcC5yZWNvcmQiLCJvcGVyYXRpb25faWQiOiIzMTA2NTI4Yi1jNGVkLTQxNDktOTgxNS04YzA1MDg4NzMyZDUiLCJwcm9kdWNlciI6eyJjb250cmFjdCI6InJ1bi1jb21tYW5kLzEiLCJwYWNrYWdlX3ZlcnNpb24iOiIwLjE0LjUifSwicmVxdWVzdF9kaWdlc3QiOiJzaGEyNTY6N2Q5YTdmN2UzYmY1ZjVkNGM0N2ZkZDVkY2Q1ZGNkZTc5NWRhNDVhMTU3Y2MyOGM2MTQ0MDgwMTVhMWYxNzBjOSIsInJ1bl9pZCI6InF1aWNrLWNsb3Nlb3V0Iiwic2NoZW1hX3ZlcnNpb24iOiIxIiwidGFyZ2V0X2lkIjoic2hhMjU2OmM3MDEzNTE3Nzg2YzBhMjFhZWFmN2EzODIwMmI1MzM0NjRlZTFhY2I0MWIzMzhjYWQzNTkyYzIyYjRmYTBkYWQifQ |
| 129fe4c4-1471-48a9-92d0-98995824546b | sha256:21b01e140333232c4e532cf079dd0ad5c0dec7473d5409b9c52cc45b5b1186b9 | eyJhc3N1cmFuY2UiOnsiaW5kZXBlbmRlbnRfaHVtYW5fcHJvb2YiOiJ1bmF2YWlsYWJsZSIsImxhbmUiOiJjb29wZXJhdGl2ZV9sb2NhbCIsInJlcGx5X3Byb3ZlbmFuY2UiOiJjYWxsZXJfZm9yd2FyZGVkX2RlbGliZXJhdGVfcmVwbHkifSwiY3JlYXRlZF9hdCI6IjIwMjYtMTAtMTJUMTY6MTU6MjMuOTQ1WiIsImVmZmVjdCI6eyJwcmV2aW91c19yZXZpc2lvbl9pZCI6Ijc1YTYxOTc0LTA3YjktNDhmNS1hNjk5LTUxY2YyYTU5YWM2YiIsInJlY29yZCI6eyJjb25maXJtYXRpb25fZGlnZXN0Ijoic2hhMjU2OmFhN2EzMjVjYTM0N2MyMjAzZDUzOWRjN2RlNGExM2VlMDczNzNmZmVkY2ZiZmVhYjRmMGYzMmMyOTNlMmMzYWIiLCJjb250ZXh0X2V2aWRlbmNlX2RpZ2VzdCI6InNoYTI1Njo5MzE3NmEzMjY0OTNiY2NlZTQ4MzhkMWM5NWMzODFkMjZkYTc5MmIxYTcxMThiN2RjMmE0ZmJlMTU2NmMyYTlhIiwibGlmZWN5Y2xlIjoiY29tcGxldGVkIiwib3IiOnsiZGlnZXN0Ijoic2hhMjU2OmFmM2YyMWJkMGFjYTFkMGEyMjU3YmJmNjQzZjViNWFiZjBlNTUzMmU4MGU3ZDg4N2M3NmUzNTM4Nzg5M2EwZWQiLCJwYXRoIjoiLmFnZGYvY29udHJvbC9hcnRlZmFjdHMvcXVpY2stY2xvc2VvdXQvT1IubWQifX0sInJlc3VsdGluZ19yZXZpc2lvbl9pZCI6ImEwZjY5NjJhLWQ5MGYtNGE4NC05MzQyLWJjOWViOTgwNDc3MiIsInJldmlzaW9uIjo2fSwiZXhwZWN0ZWRfcmV2aXNpb25faWQiOiI3NWE2MTk3NC0wN2I5LTQ4ZjUtYTY5OS01MWNmMmE1OWFjNmIiLCJraW5kIjoiY2xvc2VvdXQucmVjb3JkIiwib3BlcmF0aW9uX2lkIjoiMTI5ZmU0YzQtMTQ3MS00OGE5LTkyZDAtOTg5OTU4MjQ1NDZiIiwicHJvZHVjZXIiOnsiY29udHJhY3QiOiJydW4tY29tbWFuZC8xIiwicGFja2FnZV92ZXJzaW9uIjoiMC4xNC41In0sInJlcXVlc3RfZGlnZXN0Ijoic2hhMjU2OjIxYjAxZTE0MDMzMzIzMmM0ZTUzMmNmMDc5ZGQwYWQ1YzBkZWM3NDczZDU0MDliOWM1MmNjNDViNWIxMTg2YjkiLCJydW5faWQiOiJxdWljay1jbG9zZW91dCIsInNjaGVtYV92ZXJzaW9uIjoiMSIsInRhcmdldF9pZCI6InNoYTI1NjpjNzAxMzUxNzc4NmMwYTIxYWVhZjdhMzgyMDJiNTMzNDY0ZWUxYWNiNDFiMzM4Y2FkMzU5MmMyMmI0ZmEwZGFkIn0 |

## Evidence Bindings

- schema_version: 1

| operation_id | binding |
|---|---|
| 3106528b-c4ed-4149-9815-8c05088732d5 | eyJhY3Rpb24iOiJzdGVwLnJlY29yZCIsImFzc3VyYW5jZSI6eyJpbmRlcGVuZGVudF9odW1hbl9wcm9vZiI6InVuYXZhaWxhYmxlIiwibGFuZSI6ImNvb3BlcmF0aXZlX2xvY2FsIiwicmVwbHlfcHJvdmVuYW5jZSI6ImNhbGxlcl9mb3J3YXJkZWRfZGVsaWJlcmF0ZV9yZXBseSJ9LCJvcGVyYXRpb25faWQiOiIzMTA2NTI4Yi1jNGVkLTQxNDktOTgxNS04YzA1MDg4NzMyZDUiLCJwcm9kdWNlciI6eyJjb250cmFjdCI6InJ1bi1jb21tYW5kLzEiLCJwYWNrYWdlX3ZlcnNpb24iOiIwLjE0LjUifSwicmVwb3J0Ijp7ImRpZ2VzdCI6InNoYTI1NjoyYWRjZjA2YWFiZGZhNzI3YzM5NmY5YmUyYTc0ZjFhYTE2M2U0MGM1N2NhYjc1NzI4ZGM3NzhmOGMwOTlhNzU5IiwicGF0aCI6Ii5hZ2RmL2NvbnRyb2wvYXJ0ZWZhY3RzL3F1aWNrLWNsb3Nlb3V0L0NPREVfUkVWSUVXLm1kIn0sInJ1bl9pZCI6InF1aWNrLWNsb3Nlb3V0Iiwic2NoZW1hX3ZlcnNpb24iOiIxIiwic291cmNlX3NldF9kaWdlc3QiOiJzaGEyNTY6NzQ5ZGI5MzM4YzNkOTdmNmUyZTBiM2E5ZDIxZjcwZTUwZGNhZWJjNzc3MDk2MDdlMzJkODIyZmFjMWY2MGQ5YyIsInNvdXJjZXMiOlt7ImRpZ2VzdCI6InNoYTI1Njo1N2U1ODZjOTEwZTkxMjUzY2YwMjFkNzI2ZDBmMjMzMDJhNmE5ZGM3NTcxOGUxNDdhZmJkMjI3MGM5YWFmZjIwIiwicGF0aCI6Ii5hZ2RmL2NvbnRyb2wvYXJ0ZWZhY3RzL3F1aWNrLWNsb3Nlb3V0L1VSLm1kIiwic3RhdHVzIjoiYXBwcm92ZWQiLCJ0eXBlIjoiVVIifSx7ImRpZ2VzdCI6bnVsbCwicGF0aCI6IiIsInN0YXR1cyI6Im1pc3NpbmciLCJ0eXBlIjoiUFJEIn0seyJkaWdlc3QiOm51bGwsInBhdGgiOiIiLCJzdGF0dXMiOiJtaXNzaW5nIiwidHlwZSI6IlNEIn0seyJkaWdlc3QiOm51bGwsInBhdGgiOiIiLCJzdGF0dXMiOiJtaXNzaW5nIiwidHlwZSI6IlRQIn0seyJkaWdlc3QiOm51bGwsInBhdGgiOiIiLCJzdGF0dXMiOiJtaXNzaW5nIiwidHlwZSI6IkNEK1Rlc3RzIn1dLCJzdGVwIjoicmV2aWV3In0 |
