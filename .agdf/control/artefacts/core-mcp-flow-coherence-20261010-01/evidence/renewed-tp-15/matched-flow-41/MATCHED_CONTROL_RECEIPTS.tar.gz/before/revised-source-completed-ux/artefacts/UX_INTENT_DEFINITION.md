# UX Intent Definition
- decision: ready
Synthetic saved-filter intent; personal ownership and restore remain unchanged.
